"""Exact null probabilities for profile ambiguity conditional on arity k and ON count b.
Uniform random b-subset of {0,1}^k. Does NOT sample the empirical corpus.
"""
from math import comb
from itertools import product
import csv
from pathlib import Path

def exact_support_count(k,profile,s):
    def H(r):
        h=k-r
        a=list(profile)
        for _ in range(h):
            b=[a[0]]
            for j in range(1,len(a)-1): b.append(a[j]-b[-1])
            if a[-1]!=b[-1]: return 0
            a=b
        if any(v<0 or v>comb(r,j) for j,v in enumerate(a)): return 0
        z=1
        for j,v in enumerate(a): z*=comb(comb(r,j),v)
        return z
    return sum((-1)**(s-r)*comb(s,r)*H(r) for r in range(s+1))

def records(k):
    counts=[comb(k,j) for j in range(k+1)]
    out={b:[0,0,0] for b in range(2**k+1)}
    for A in product(*(range(c+1) for c in counts)):
        b=sum(A)
        multiplicity=1
        for c,v in zip(counts,A): multiplicity*=comb(c,v)
        sizes=[s for s in range(k+1) if exact_support_count(k,A,s)>0]
        ca=len(sizes)>1
        labelled=(len(sizes)>1 or any(0<s<k for s in sizes))
        out[b][0]+=multiplicity
        out[b][1]+=multiplicity*ca
        out[b][2]+=multiplicity*labelled
    for b,(total,ca,lab) in out.items():
        assert total==comb(2**k,b),(k,b,total)
        yield (k,b,total,ca,lab,ca/total,lab/total)

if __name__=='__main__':
    out=Path(__file__).with_name('exact_null_k3_k4.csv')
    with out.open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['k','positive_count_b','total_tables','cardinality_ambiguous','labelled_ambiguous','Pr_cardinality_ambiguous','Pr_labelled_ambiguous'])
        for k in (3,4):
            rows=list(records(k));w.writerows(rows)
            print('k',k,'unconditional card',sum(r[3] for r in rows)/2**(2**k),'labelled',sum(r[4] for r in rows)/2**(2**k))
    print(out)
