"""Read-only verifier for the n=5 profile (0,0,1,2,1,0).
Run in Colab after mounting Drive; does not change checkpoints.
"""
import argparse,hashlib,itertools,json,collections
from pathlib import Path

def support(f):
    s=0
    for k in range(5):
        if any(((f>>x)&1)!=((f>>(x^(1<<k)))&1) for x in range(32) if not x&(1<<k)):
            s |= 1<<k
    return s

def verify_tree(path, bound=12):
    t=json.loads(Path(path).read_text(encoding='utf-8'))
    levels={w:[x for x in range(32) if x.bit_count()==w] for w in [2,3,4]}
    n=0; maxdepth=0; lengths=collections.Counter(); labels=collections.Counter()
    for a in levels[2]:
      for b,c in itertools.combinations(levels[3],2):
       for d in levels[4]:
        f=(1<<a)|(1<<b)|(1<<c)|(1<<d)
        node=t; seen=set();depth=0
        while isinstance(node,dict) and 'query' in node:
            q=node['query']; assert isinstance(q,int) and 0<=q<32 and q.bit_count() in (2,3,4),('bad query',q)
            assert q not in seen,('duplicate query',q)
            seen.add(q);depth+=1
            node=node['one' if f>>q&1 else 'zero']
        assert isinstance(node,dict) and 'support' in node,('bad leaf',node)
        actual=support(f)
        assert node['support']==actual,(a,b,c,d,node,actual)
        n+=1;maxdepth=max(maxdepth,depth);lengths[depth]+=1;labels[actual]+=1
    assert n==2250
    assert maxdepth<=bound,(maxdepth,bound)
    print('INDEPENDENT TREE CHECK PASS: 2250/2250; max depth',maxdepth)
    print('Path lengths:',dict(sorted(lengths.items())))
    print('Support counts:',dict(sorted(labels.items())))
    print('Tree SHA256:',hashlib.sha256(Path(path).read_bytes()).hexdigest())
    return maxdepth

def inspect(root):
    print('ROOT:',root)
    tree=root/'tree_depth12.json'
    if tree.exists():verify_tree(tree)
    else:print('MISSING tree_depth12.json: cannot certify upper bound from this folder')
    p=root/'certified_results.json'
    if p.exists():
        obj=json.loads(p.read_text());print('Reported depth statuses:',json.dumps(obj,indent=2))
        for depth in range(12):
            s=obj.get(str(depth),{}).get('status')
            if s is None:print('Depth',depth,'has no direct entry (may be covered by monotonicity)')
        print('IMPORTANT: NO statuses are solver claims, not independently checked proof certificates.')
    else:print('MISSING certified_results.json')
    for name in ('current','previous'):
        meta=root/(name+'.json');blob=root/(name+'.bin')
        if not meta.exists() or not blob.exists():continue
        m=json.loads(meta.read_text()); print('CHECKPOINT',name,'generation',m.get('generation'),'status',m.get('status'))
        expected=m.get('sha256');actual=hashlib.sha256()
        with blob.open('rb') as f:
            for part in iter(lambda:f.read(8*1024*1024),b''):actual.update(part)
        print('CHECKPOINT integrity:', 'PASS' if actual.hexdigest()==expected else 'FAIL')
    print('Exact optimum =12 requires an independent rigorous exclusion of depth <=11.')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('root',type=Path)
    args=parser.parse_args();inspect(args.root)
