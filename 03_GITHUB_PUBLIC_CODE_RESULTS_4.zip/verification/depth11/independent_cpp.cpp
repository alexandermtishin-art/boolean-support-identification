// Independent bitset decision-tree verifier for Boolean support identification.
// Does not read memo from the Colab solver. Returns UNKNOWN on resource limit.
#include <bits/stdc++.h>
using namespace std;
constexpr int N=2250,W=(N+63)/64;
using State=array<uint64_t,W>;
struct Key {State s; uint8_t d; bool operator==(Key const& o)const{return d==o.d&&s==o.s;}};
struct Hash {size_t operator()(Key const& k)const{uint64_t h=0x9e3779b97f4a7c15ULL^k.d;for(uint64_t x:k.s){x^=x>>30;x*=0xbf58476d1ce4e5b9ULL;x^=x>>27;x*=0x94d049bb133111ebULL;x^=x>>31;h^=x+0x9e3779b97f4a7c15ULL+(h<<6)+(h>>2);}return (size_t)h;}};
vector<uint32_t> truth; vector<int> label;vector<int> query;vector<State> yes;array<State,32> classes{};
unordered_set<Key,Hash> no_cache;uint64_t visited=0,limit_nodes=1000000;
bool same_label(State const& s){int found=-1;for(int i=0;i<N;i++)if(s[i>>6]>>(i&63)&1){if(found<0)found=label[i];else if(label[i]!=found)return false;}return true;}
int pop(State const&s){int t=0;for(auto x:s)t+=__builtin_popcountll(x);return t;}
struct Limit{};
bool solve(State const&s,int d){if(++visited>limit_nodes)throw Limit{};if(same_label(s))return true;if(d==0)return false;
 Key key{s,(uint8_t)d};if(no_cache.find(key)!=no_cache.end())return false;
 vector<pair<int,State>> cand;for(size_t qi=0;qi<query.size();qi++){State a{};int c=0;for(int j=0;j<W;j++){a[j]=s[j]&yes[qi][j];c+=__builtin_popcountll(a[j]);}int n=pop(s);if(c>0&&c<n)cand.push_back({abs(n-2*c),a});}
 sort(cand.begin(),cand.end(),[](auto const&a,auto const&b){return a.first<b.first;});
 for(auto const&[score,a]:cand){State b{};for(int j=0;j<W;j++)b[j]=s[j]^a[j];if(solve(a,d-1)&&solve(b,d-1))return true;}
 no_cache.insert(move(key));return false;
}
void generate(){vector<int> l2,l3,l4;for(int x=0;x<32;x++){int w=__builtin_popcount((unsigned)x);if(w==2)l2.push_back(x);if(w==3)l3.push_back(x);if(w==4)l4.push_back(x);}
 for(int a:l2)for(int i=0;i<(int)l3.size();i++)for(int j=i+1;j<(int)l3.size();j++)for(int b:l4){uint32_t t=(1u<<a)|(1u<<l3[i])|(1u<<l3[j])|(1u<<b);truth.push_back(t);int support=0;for(int bit=0;bit<5;bit++)for(int x=0;x<32;x++)if(!(x&(1<<bit))&&((t>>x&1)!=(t>>(x|(1<<bit))&1)))support|=1<<bit;label.push_back(support);}
 if(truth.size()!=N)throw runtime_error("bad family size");for(int x=0;x<32;x++){int w=__builtin_popcount((unsigned)x);if(w!=2&&w!=3&&w!=4)continue;State m{};for(int i=0;i<N;i++)if(truth[i]>>x&1)m[i>>6]|=1ULL<<(i&63);query.push_back(x);yes.push_back(m);}
}
int main(int argc,char**argv){int depth=argc>1?atoi(argv[1]):3;limit_nodes=argc>2?stoull(argv[2]):1000000;generate();State root{};for(int i=0;i<N;i++)root[i>>6]|=1ULL<<(i&63);try{bool ans=solve(root,depth);cout<<"n=5 functions="<<N<<" depth="<<depth<<" result="<<(ans?"YES":"NO")<<" nodes="<<visited<<" cached_negative="<<no_cache.size()<<"\n";}catch(Limit const&){cout<<"n=5 functions="<<N<<" depth="<<depth<<" result=UNKNOWN nodes="<<visited<<" cached_negative="<<no_cache.size()<<"\n";return 2;}}
