"""Independent exact support-identification depth-decision DP.
No reuse of production solver, checkpoint, or its pruning implementation.
Designed for small-depth correctness smoke tests, NOT depth-11 certification.
"""
from itertools import combinations
from functools import lru_cache
from collections import Counter
from argparse import ArgumentParser

def make_instance(n, counts):
    layers=[[x for x in range(1<<n) if x.bit_count()==w] for w in range(n+1)]
    tables=[]
    def rec(w, mask):
        if w==n+1:
            tables.append(mask);return
        for subset in combinations(layers[w],counts[w]):
            add=sum(1<<a for a in subset)
            rec(w+1,mask|add)
    rec(0,0)
    labels=[]
    for t in tables:
        support=0
        for i in range(n):
            if any(((t>>x)&1)!=((t>>(x^(1<<i)))&1) for x in range(1<<n) if not x&(1<<i)):
                support|=1<<i
        labels.append(support)
    queries=[x for x in range(1<<n) if 0<sum((t>>x)&1 for t in tables)<len(tables)]
    yes={x:sum(1<<i for i,t in enumerate(tables) if (t>>x)&1) for x in queries}
    return tables,labels,queries,yes

def decision(tables, labels, queries, yes, depth):
    full=(1<<len(tables))-1
    labelmask={s:sum(1<<i for i,l in enumerate(labels) if l==s) for s in set(labels)}
    @lru_cache(None)
    def solve(state,remaining):
        if sum(bool(state & m) for m in labelmask.values()) <= 1: return True
        if remaining==0:return False
        for x in queries:
            a=state & yes[x]
            if not a or a==state:continue
            if solve(a,remaining-1) and solve(state^a,remaining-1):return True
        return False
    answer=solve(full,depth)
    return answer,solve.cache_info()

if __name__=='__main__':
    p=ArgumentParser();p.add_argument('--n',type=int,default=5);p.add_argument('--depth',type=int,default=3);a=p.parse_args()
    counts=[0]*(a.n+1)
    if a.n==5:counts[2:5]=[1,2,1]
    elif a.n==3:counts[1:3]=[2,2]
    else:raise ValueError('Only supplied test profiles n=3,5')
    F,L,Q,Y=make_instance(a.n,counts)
    print('functions',len(F),'labels',len(set(L)),'queries',len(Q))
    v,ci=decision(F,L,Q,Y,a.depth)
    print('depth',a.depth,'result',('YES' if v else 'NO'),'cache',ci)
