# Independent C++ decision procedure: status

Algorithm independently enumerates the exact 2,250-function class (one positive at weight 2, two at weight 3, one at weight 4). It computes exact support labels, forms the 25 informative address partitions, and recursively evaluates whether a binary decision tree can determine the support within a specified depth. Negative states are memoized as fixed-width 2,250-bit bitsets together with remaining depth. No Colab checkpoint or original solver code is read.

## Actual completed tests (local build, g++ -O3 -std=c++17)

```
./independent_cpp 3 1000000  => NO, 6,596 nodes
./independent_cpp 4 1000000  => NO, 101,716 nodes
./independent_cpp 5 1000000  => NO, 842,776 nodes
./independent_cpp 6 1000000  => UNKNOWN (node cap)
```

Depths 3–5 reproduce a subset of prior independent Python checks and validate the separate implementation. `UNKNOWN` is a resource cutoff, **never a mathematical exclusion**. No independently verified depth-11 `NO` has been produced. The known depth-12 YES certificate is independent and should be preserved separately.

## Running additional tests

```
g++ -O3 -std=c++17 -o independent_cpp independent_cpp.cpp
./independent_cpp 6 20000000
./independent_cpp 11 20000000
```

Raise the node cap only if memory allows. The current implementation does not provide disk-resumable checkpoints; do not assume that it will finish depth 11. To certify depth 11 requires an exhaustive run or a compact independently verifiable UNSAT-style proof.
