"""Independent exhaustive structural checks for the n=5 profile t^2+2t^3+t^4.
No dependency on the production C++ solver or its memo cache.
"""
from itertools import combinations, permutations
from collections import Counter

def weight(x):return x.bit_count()
layer={k:[x for x in range(32) if weight(x)==k] for k in (2,3,4)}

def support(table):
    return sum((1<<i) for i in range(5) if any(((table>>x)&1)!=((table>>(x^(1<<i)))&1) for x in range(32) if not x&(1<<i)))
functions=[]
for a in layer[2]:
    for b,c in combinations(layer[3],2):
        for d in layer[4]:
            table=(1<<a)|(1<<b)|(1<<c)|(1<<d)
            functions.append((table,support(table)))
assert len(functions)==2250 and len({f for f,s in functions})==2250
hist=Counter(s for f,s in functions)
assert len(hist)==16,(len(hist),hist)
# Check that each of 25 available root queries belongs to precisely one S5 orbit,
# represented by its Hamming weight.
perms=list(permutations(range(5)))
def permute_addr(x,p):return sum((1<<p[i]) for i in range(5) if (x>>i)&1)
queries=sum((layer[k] for k in (2,3,4)),[])
for x in queries:
    orbit={permute_addr(x,p) for p in perms}
    assert orbit==set(layer[weight(x)]),(x,orbit)
# Verify label counts and branch partitions for all 25 queries.
for q in queries:
    yes=[s for f,s in functions if (f>>q)&1]
    no=[s for f,s in functions if not (f>>q)&1]
    assert len(yes)+len(no)==2250
    assert yes and no
    assert len(set(yes))>1 and len(set(no))>1
# Ensure memo keys (yes-mask, no-mask, remaining depth) are injectively packed
# for disjoint queried-address masks, for every depth 0..12.
for depth in range(13):
    for q in range(25):
        y=1<<q
        for t in range(25):
            if q==t: continue
            n=1<<t
            packed=y|(n<<25)|(depth<<50)
            assert (packed&((1<<25)-1))==y
            assert ((packed>>25)&((1<<25)-1))==n
            assert packed>>50==depth
            assert packed < (1<<54)
print('PASS: 2250 unique functions,',len(hist),'support classes, 25 query partitions, 3 root orbits, cache-key packing')
print('Support-class multiplicities:',dict(sorted(hist.items())))
print('RESULT: structural checks only; depth-11 NO is NOT certified.')
