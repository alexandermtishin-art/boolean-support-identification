# Independent decision-tree DP: further negative-depth audit (2026-10-22)

This verifier is a new Python implementation, not derived from the production C++ search or its cache. It enumerates the complete profile class and computes essential supports directly from truth tables. The recursion is exhaustive over all informative addressed queries, with no pruning beyond memoization and elimination of constant-answer questions.

Commands:

```
python independent_dp.py --n 3 --depth 2
python independent_dp.py --n 3 --depth 3
python independent_dp.py --n 5 --depth 3
python independent_dp.py --n 5 --depth 4
python independent_dp.py --n 5 --depth 5
python independent_dp.py --n 5 --depth 6
python independent_dp.py --n 5 --depth 7
```

Observed results:

| n | profile | depth | verdict | unique memoized states |
|---|---|---:|---|---:|
| 3 | (0,2,2,0) | 2 | NO | 22 |
| 3 | (0,2,2,0) | 3 | YES | 14 |
| 5 | (0,0,1,2,1,0) | 3 | NO | 3,861 |
| 5 | (0,0,1,2,1,0) | 4 | NO | 36,389 |
| 5 | (0,0,1,2,1,0) | 5 | NO | 191,904 |
| 5 | (0,0,1,2,1,0) | 6 | NO | 723,086 |
| 5 | (0,0,1,2,1,0) | 7 | NO | 2,399,529 |

All verdicts were obtained by executing the above code, and not read from archival result files.

The new tests independently certify the absence of depths 0–7 for n=5 (by monotonicity), not 8–11. In particular **this does not establish Q_A=12**. The independent checked depth-12 tree establishes Q_A <= 12. A separate, complete, verifiable exclusion of depth 11 is still necessary. The production solver's NO for 11 is evidence only until audited with independent computation or a verifiable proof certificate.
