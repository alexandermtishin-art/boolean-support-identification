from itertools import combinations
from math import comb
for n in (5,6,7):
 layers={k:[sum(1<<i for i in c) for c in combinations(range(n),k)] for k in (2,3,4)}
 cubes=[]
 for u in layers[2]:
  zero=[i for i in range(n) if not u>>i&1]
  for i,j in combinations(zero,2):cubes.append(frozenset((u,u|1<<i,u|1<<j,u|1<<i|1<<j)))
 def supp(S):return frozenset(i for i in range(n) if any(((v>>i)&1 and (v^(1<<i)) not in S) or (not ((v>>i)&1) and (v^(1<<i)) not in S) for v in S))
 fails=[]
 for k,L in layers.items():
  for a,b in combinations(L,2):
   ok=False
   for x,y in ((a,b),(b,a)):
    for S in cubes:
     if x in S and y not in S:
      T=(S-{x})|{y}
      if supp(S)!=supp(T):ok=True;break
    if ok:break
   if not ok:fails.append((k,a,b))
 print(n,'cubes',len(cubes),'pairs',sum(comb(len(L),2) for L in layers.values()),'fails',len(fails),fails[:3])
