#!/usr/bin/env python3
"""Further structured nulls, arity-matched to the corpus (k >= 3): uniform random truth tables, random signed threshold functions, random read-once AND/OR/NOT
formulas, and random nested canalizing functions with the number of essential inputs not forced. Each draw is conditioned on all k inputs being essential, and the comparison is restricted to corpus rules with all inputs
essential. Reports expected ambiguous occurrences against the observed count. Usage: python structured_null_more.py [nodes.csv] [N] [seed]"""
import csv, os, sys, random, collections
here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(here, '..', 'baseline'))
from dgsupport.core import profile_of, spectrum, support_of
nodes = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, '..', '..', 'k6', 'baseline', 'results', 'real_networks_nodes.csv')
N = int(sys.argv[2]) if len(sys.argv) > 2 else 1000
random.seed(int(sys.argv[3]) if len(sys.argv) > 3 else 1)

def threshold(k):
    w = [random.choice((-1, 1)) * random.randint(1, 3) for _ in range(k)]
    lo = sum(x for x in w if x < 0); hi = sum(x for x in w if x > 0)
    t = random.randint(lo, hi)
    return sum(1 << y for y in range(1 << k) if sum(w[i] for i in range(k) if (y >> i) & 1) >= t)

def readonce(k):
    vars_ = list(range(k)); random.shuffle(vars_)
    def build(vs):
        if len(vs) == 1:
            neg = random.randint(0, 1)
            return lambda y, v=vs[0], neg=neg: ((y >> v) & 1) ^ neg
        c = random.randint(1, len(vs) - 1); a, b = build(vs[:c]), build(vs[c:])
        op = random.randint(0, 1); neg = random.randint(0, 1)
        return (lambda y: (a(y) & b(y)) ^ neg) if op else (lambda y: (a(y) | b(y)) ^ neg)
    f = build(vars_)
    return sum(f(y) << y for y in range(1 << k))

def ncf(k):
    order = random.sample(range(k), k); a = [random.randint(0, 1) for _ in range(k)]
    b = [random.randint(0, 1) for _ in range(k)]; d = random.randint(0, 1); tt = 0
    for y in range(1 << k):
        out = d
        for i, v in enumerate(order):
            if ((y >> v) & 1) == a[i]: out = b[i]; break
        tt |= out << y
    return tt

cnt = collections.Counter(); obs = 0
for r in csv.DictReader(open(nodes)):
    k = int(r['k'])
    if k >= 3 and r['essential'] == r['k']: cnt[k] += 1; obs += int(r['nsizes']) > 1   # rules with all k inputs essential
def uniform(k): return random.getrandbits(1 << k)
for name, gen in (('uniform', uniform), ('threshold', threshold), ('read-once', readonce), ('nested canalizing', ncf)):
    tot = 0.0
    for k in sorted(cnt):
        n = N if k <= 8 else max(100, N // 10)
        amb = 0
        for _ in range(n):
            while True:
                tt = gen(k)
                if len(support_of(tt, k)) == k: break   # condition on all inputs essential
            amb += len(spectrum(profile_of(tt, k))) > 1
        tot += cnt[k] * amb / n
    print('%-18s expected ambiguous occurrences %.2f  (observed %d)' % (name, tot, obs), flush=True)
