#!/usr/bin/env python3
"""Structured null model: random nested canalizing functions (NCFs) with the same arity as each corpus rule.
For every arity k of the corpus (k >= 3) draw N random NCFs with all k inputs essential, compute the support spectrum of the
sector profile (Theorem 1), and record the share whose profile admits more than one support size. The expected number of
ambiguous occurrences is sum_k n_k * share_k, to be compared with the 71 observed.
Usage: python structured_null_ncf.py [nodes.csv] [N] [seed]"""
import csv, os, sys, random, collections
here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(here, '..', 'baseline'))
from dgsupport.core import profile_of, spectrum
nodes = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, '..', '..', 'k6', 'baseline', 'results', 'real_networks_nodes.csv')
N = int(sys.argv[2]) if len(sys.argv) > 2 else 2000
random.seed(int(sys.argv[3]) if len(sys.argv) > 3 else 1)

def random_ncf(k):
    """Nested canalizing function: order of variables, canalizing value a_i, canalized output b_i, final default b_k+1 = not b_k."""
    order = random.sample(range(k), k)
    a = [random.randint(0, 1) for _ in range(k)]
    b = [random.randint(0, 1) for _ in range(k)]
    default = 1 - b[-1]            # makes the last variable essential
    tt = 0
    for y in range(1 << k):
        out = default
        for i, v in enumerate(order):
            if ((y >> v) & 1) == a[i]:
                out = b[i]; break
        tt |= out << y
    return tt

cnt = collections.Counter(); obs_amb = 0
for r in csv.DictReader(open(nodes)):
    k = int(r['k'])
    if k >= 3:
        cnt[k] += 1
        obs_amb += int(r['nsizes']) > 1
tot = 0.0; rows = []
for k in sorted(cnt):
    n = N if k <= 10 else max(200, N // 10)
    amb = sum(len(spectrum(profile_of(random_ncf(k), k))) > 1 for _ in range(n))
    share = amb / n; tot += cnt[k] * share
    rows.append((k, cnt[k], n, amb, share))
    print('k=%2d occurrences %4d draws %5d ambiguous %5d share %.4f expected %.2f' % (k, cnt[k], n, amb, share, cnt[k] * share), flush=True)
print('observed ambiguous', obs_amb, 'expected under random NCF null %.2f' % tot)
