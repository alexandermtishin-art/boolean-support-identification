# Exact certificates for 20 ambiguous rules with three or four inputs (Supplement Appendix E)

`certificates.csv` holds the per-table heuristic results of the corpus-wide search (columns k, truth_table, profile, support_size, ambiguous, cert_with_profile, cert_no_profile, addresses).

```bash
python exact_certificates_small.py          # writes results/exact_certificates_k3_k4.csv and results/summary.json
python independent_milp_verify.py           # MILP cross-check, expects PASS for 20 distinct truth tables
```

The exact minima are 13 of length 2, six of length 3 and one of length 7; each equals the corresponding heuristic upper bound. Both scripts accept optional paths for the input and output files.
