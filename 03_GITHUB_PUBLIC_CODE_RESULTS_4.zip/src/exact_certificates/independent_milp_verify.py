#!/usr/bin/env python3
"""Independent MILP cross-check using scipy.optimize.milp, not the enumeration certificate search."""
import csv,zipfile,io,itertools,numpy as np
from scipy.optimize import milp,LinearConstraint,Bounds
from scipy.sparse import lil_matrix
from exact_certificates_small import all_functions,support
# usage: python independent_milp_verify.py [certificates.csv] [exact_certificates_k3_k4.csv]
import os,sys
here=os.path.dirname(os.path.abspath(__file__))
csv_path=sys.argv[1] if len(sys.argv)>1 else os.path.join(here,'certificates.csv')
exact_path=sys.argv[2] if len(sys.argv)>2 else os.path.join(here,'results','exact_certificates_k3_k4.csv')
data=list(csv.DictReader(open(csv_path)))
rows=[r for r in data if int(r['k']) in (3,4) and r['ambiguous']=='1']
cache={}
for r in rows:
 k=int(r['k']);n=1<<k;profile=tuple(map(int,r['profile'].split())); target=int(r['truth_table']);s=support(k,target)
 if (k,profile) not in cache:cache[k,profile]=list(all_functions(k,profile))
 wrong=[g for g in cache[k,profile] if support(k,g)!=s]
 if not wrong:opt=0
 else:
  A=lil_matrix((len(wrong),n))
  for i,g in enumerate(wrong):
   delta=g^target
   for j in range(n):
    if delta>>j&1:A[i,j]=1
  res=milp(c=np.ones(n),integrality=np.ones(n),bounds=Bounds(np.zeros(n),np.ones(n)),constraints=LinearConstraint(A.tocsr(),np.ones(len(wrong)),np.full(len(wrong),np.inf)),options={'time_limit':30})
  assert res.status==0,(k,profile,res.message)
  opt=int(round(res.fun))
 print(k,profile,target,opt,flush=True)
 r['verified_opt']=opt
expected={(int(r['k']),int(r['truth_table'])):int(r['exact_min_certificate']) for r in csv.DictReader(open(exact_path))}
assert all(r['verified_opt']==expected[int(r['k']),int(r['truth_table'])] for r in rows)
print('INDEPENDENT_MILP_CROSSCHECK: PASS',len(rows),'distinct truth tables')
