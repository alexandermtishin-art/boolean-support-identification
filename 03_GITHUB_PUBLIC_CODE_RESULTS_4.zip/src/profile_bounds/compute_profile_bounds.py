#!/usr/bin/env python3
"""Lower and upper bounds on adaptive support identification for the ambiguous corpus profiles (Supplement Appendix H).

Input: node-level table k6/baseline/results/real_networks_nodes.csv (columns model,node,k,essential,profile,kmin,kmax,nsizes,functions).
A profile is support-cardinality ambiguous when nsizes > 1. Distinct profiles are grouped by (k, layer-count vector).
Lower bound: ceil(log2(C(k,smin)+C(k,smax))). Upper bound: sum over mixed layers j (0 < a_j < C(k,j)) of C(k,j)-1.
Profiles with exact adaptive minimax values (Supplement Appendix E) are flagged.
Usage: python compute_profile_bounds.py [nodes.csv] [output.csv]
"""
import csv, math, os, sys, collections
here = os.path.dirname(os.path.abspath(__file__))
nodes = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, '..', '..', 'k6', 'baseline', 'results', 'real_networks_nodes.csv')
out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(here, 'profile_bounds_53.csv')
EXACT = {(3, (0,1,1,0)), (3, (0,1,2,1)), (3, (0,2,2,0)), (3, (1,2,1,0)), (4, (0,1,1,0,0)), (4, (0,0,1,1,0))}
occ = collections.Counter(); info = {}
for r in csv.DictReader(open(nodes)):
    k = int(r['k'])
    if k < 3 or int(r['nsizes']) <= 1: continue
    A = tuple(map(int, r['profile'].split()))
    occ[k, A] += 1; info[k, A] = (int(r['kmin']), int(r['kmax']))
rows = []
for (k, A), n in sorted(occ.items()):
    smin, smax = info[k, A]
    mixed = [j for j in range(k + 1) if 0 < A[j] < math.comb(k, j)]
    lower = math.ceil(math.log2(math.comb(k, smin) + math.comb(k, smax)))
    upper = sum(math.comb(k, j) - 1 for j in mixed)
    rows.append(dict(k=k, profile=' '.join(map(str, A)), occurrences=n, smin=smin, smax=smax,
                     mixed_layers=' '.join(map(str, mixed)), lower_bound=lower, upper_bound=upper,
                     exact_minimax_computed=int((k, A) in EXACT)))
with open(out, 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
unsolved = [r for r in rows if not r['exact_minimax_computed']]
print('occurrences', sum(r['occurrences'] for r in rows), 'distinct profiles', len(rows), 'exact', len(rows) - len(unsolved), 'unsolved', len(unsolved))
print('lower bounds', min(r['lower_bound'] for r in unsolved), 'to', max(r['lower_bound'] for r in unsolved))
print('upper bounds', min(r['upper_bound'] for r in unsolved), 'to', max(r['upper_bound'] for r in unsolved))
by = collections.defaultdict(lambda: [0, 0])
for r in rows: by[r['k']][0] += r['occurrences']; by[r['k']][1] += 1
print('by k (occurrences/profiles):', {k: tuple(v) for k, v in sorted(by.items())})
