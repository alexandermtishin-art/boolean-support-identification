// NOTE: addresses are stored in a 32-bit mask, so N = C(m,j) must be at most 32 (largest case here is (m,j)=(8,2), N=28).
// Stars are the sets avoid(c); support_claim.py checks directly from truth tables that only stars have proper support for the small cases.
// Usage: ./thm2_game m j   (prints the exact minimax value and the formula T = C(m-1,j-1)+ceil((m-1)/j))
// Exact minimax of the adaptive support-identification game on F(m,j) (Theorem 2 class).
// Hypotheses: all a-subsets (a=C(m-1,j)) of the N=C(m,j) weight-j addresses are the positive sets.
// A positive set equal to {x : c not in x} is the star guard missing c (support = [m]\{c}); every other set has full support.
// State = (P,Z) answered positive/negative addresses. Terminal iff all consistent hypotheses share one support.
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long u64; typedef unsigned u32;
int m,j,N,a; vector<u32> addr, avoid;
double Cb[64][64];
static inline u64 binom(int n,int k){ if(k<0||k>n||n<0) return 0; return (u64)llround(Cb[n][k]); }
struct Ent{u64 key; signed char lo, hi;}; // lo: largest d known losing, hi: smallest d known winning
vector<Ent> tab; u64 mask_;
Ent& slot(u64 key){ u64 h=key*0x9E3779B97F4A7C15ULL; size_t i=(h>>20)&mask_; while(tab[i].key!=~0ULL && tab[i].key!=key) i=(i+1)&mask_; if(tab[i].key==~0ULL){tab[i].key=key;tab[i].lo=-1;tab[i].hi=100;} return tab[i]; }
u64 states=0;
static inline u64 total(u32 P,u32 Z){ int p=__builtin_popcount(P), z=__builtin_popcount(Z); int need=a-p, fr=N-p-z; return binom(fr,need); }
static inline int stars(u32 P,u32 Z){ int c=0; for(int i=0;i<m;i++){ u32 A=avoid[i]; if((P&~A)==0 && (Z&A)==0) c++; } return c; }
bool terminal(u32 P,u32 Z){ int s=stars(P,Z); if(s==0) return true; u64 t=total(P,Z); return (t-(u64)s)==0 && s==1; }
bool win(u32 P,u32 Z,int d){
  if(terminal(P,Z)) return true;
  if(d==0) return false;
  u64 key=(u64)P|((u64)Z<<32);
  Ent&e=slot(key); if(e.hi<=d) return true; if(e.lo>=d) return false;
  states++;
  u32 used=P|Z; bool res=false;
  for(int x=0;x<N && !res;x++){ if(used>>x&1) continue;
    u32 b=1u<<x; bool ok=true;
    if(total(P|b,Z)>0 && !win(P|b,Z,d-1)) ok=false;
    if(ok && total(P,Z|b)>0 && !win(P,Z|b,d-1)) ok=false;
    if(ok) res=true;
  }
  Ent&e2=slot(key); if(res) e2.hi=min<int>(e2.hi,d); else e2.lo=max<int>(e2.lo,d);
  return res;
}
int main(int argc,char**argv){ m=atoi(argv[1]); j=atoi(argv[2]); int maxD=argc>3?atoi(argv[3]):60;
  for(int n=0;n<64;n++){Cb[n][0]=1;for(int k=1;k<=n;k++)Cb[n][k]=Cb[n-1][k-1]+(k<=n-1?Cb[n-1][k]:0);}
  for(u32 x=0;x<(1u<<m);x++) if(__builtin_popcount(x)==j) addr.push_back(x);
  N=addr.size(); a=(int)binom(m-1,j); avoid.assign(m,0);
  for(int c=0;c<m;c++) for(int i=0;i<N;i++) if(!(addr[i]>>c&1)) avoid[c]|=1u<<i;
  size_t cap=1; while(cap<(size_t)1<<27) cap<<=1; tab.assign(cap,Ent{~0ULL,-1,100}); mask_=cap-1;
  int T=(int)(binom(m-1,j-1)+(m-1+j-1)/j);
  for(int d=0;d<=maxD;d++){ bool w=win(0,0,d); printf("m=%d j=%d N=%d a=%d depth %d: %s (states %llu)\n",m,j,N,a,d,w?"WIN":"lose",states); fflush(stdout); if(w){ printf("MINIMAX=%d  formula T=%d\n",d,T); return 0; } }
}
