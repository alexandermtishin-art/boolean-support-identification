// Executes the candidate-elimination procedure for Theorem 2 against every adversary (all answer sequences
// consistent with the sector profile) and reports the worst-case number of queries and any identification failure.
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <unordered_map>
typedef unsigned __int128 u64;
static inline int pc(u64 x){return __builtin_popcountll((unsigned long long)x)+__builtin_popcountll((unsigned long long)(x>>64));}
static u64 Cb[130][130];
int m,j,P,a,b; std::vector<u64> avoid; std::vector<int> pts; static unsigned long long CbDummy;
struct Key{u64 o,z; bool operator==(const Key&x)const{return o==x.o&&z==x.z;}};
struct H{size_t operator()(const Key&k)const{unsigned long long a=(unsigned long long)k.o^((unsigned long long)(k.o>>64)*0x1234567ULL),c=(unsigned long long)k.z^((unsigned long long)(k.z>>64)*0x7654321ULL);return a*0x9E3779B97F4A7C15ULL ^ (c+0x7F4A7C15ULL)*0xC2B2AE3D27D4EB4FULL;}};
std::unordered_map<Key,int,H> memo; long errors=0;
static int centers(u64 o,u64 z){int C=0;for(int i=0;i<m;i++) if((o&~avoid[i])==0&&(z&avoid[i])==0) C|=1<<i; return C;}
static int dfs(u64 o,u64 z){
  int q=pc(o|z), r=P-q, c=a-pc(o);
  int C=centers(o,z), nC=__builtin_popcount(C);
  if(nC==0) return 0;                 // full support certified
  if(Cb[r][c]==1){                    // unique completion
    if(nC!=1) errors++;               // must be a single star
    return 0;}
  Key k{o,z}; auto it=memo.find(k); if(it!=memo.end()) return it->second;
  // choose query by the procedure
  int target = nC>j ? j : (nC>=2 ? nC-1 : -1);
  int pick=-1;
  for(int p=0;p<P && pick<0;p++){ if((int)(((o|z)>>p)&1)) continue;
    if(target>=0){ if(__builtin_popcount(pts[p]&C)==target) pick=p; }
    else { int i=__builtin_ctz(C); if((pts[p]>>i)&1) pick=p; } }
  if(pick<0){ errors++; return 1000; }
  u64 bit=((u64)1)<<pick; int best=0;
  if(c>=1) best=std::max(best,1+dfs(o|bit,z));
  if(c<=r-1) best=std::max(best,1+dfs(o,z|bit));
  memo[k]=best; return best;}
int main(int argc,char**argv){
  m=atoi(argv[1]); j=atoi(argv[2]);
  for(int n=0;n<130;n++){Cb[n][0]=1;for(int k=1;k<=n;k++)Cb[n][k]=Cb[n-1][k-1]+(k<=n-1?Cb[n-1][k]:0);}
  for(int x=0;x<(1<<m);x++) if(__builtin_popcount(x)==j) pts.push_back(x);
  P=pts.size(); if(P>127){puts("too many addresses");return 1;}
  a=Cb[m-1][j]; b=Cb[m-1][j-1];
  avoid.assign(m,0); for(int i=0;i<m;i++) for(int p=0;p<P;p++) if(!((pts[p]>>i)&1)) avoid[i]|=((u64)1)<<p;
  int T=b+(m-1+j-1)/j; int w=dfs(0,0);
  printf("m=%d j=%d: worst-case queries of procedure=%d, claimed T=%d, identification errors=%ld, states=%zu\n",m,j,w,T,errors,memo.size());
  return 0;}
