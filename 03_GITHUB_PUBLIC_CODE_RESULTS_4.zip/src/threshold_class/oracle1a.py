"""Executable model of the Theorem 2 threshold-profile class and the candidate-elimination procedure."""
import itertools, random
from math import comb

class Class1A:
    def __init__(self, m, j):
        self.m, self.j = m, j
        self.pts = [frozenset(c) for c in itertools.combinations(range(m), j)]
        self.P = len(self.pts)
        self.a = comb(m - 1, j)
        self.b = comb(m - 1, j - 1)
        self.p = -(-(m - 1) // j)
        self.T = self.b + self.p
        self.idx = {pt: i for i, pt in enumerate(self.pts)}
        self.avoid = [frozenset(i for i, pt in enumerate(self.pts) if c not in pt) for c in range(m)]  # ones of f_c

    def star(self, c):
        """Truth values on weight-j addresses for f_c (1 iff address avoids c)."""
        return [0 if c in pt else 1 for pt in self.pts]

    def random_full_support(self, rng):
        """Random function in the class with full support (uniform over ones-sets, rejection of stars)."""
        while True:
            ones = set(rng.sample(range(self.P), self.a))
            if not any(ones == set(self.avoid[c]) for c in range(self.m)):
                return [1 if i in ones else 0 for i in range(self.P)]

    def candidates(self, ones, zeros):
        return [c for c in range(self.m) if ones <= self.avoid[c] and not (zeros & self.avoid[c])]

    def next_query(self, ones, zeros):
        C = self.candidates(ones, zeros)
        nC = len(C)
        asked = ones | zeros
        if nC > self.j:
            target = self.j
        elif nC >= 2:
            target = nC - 1
        else:
            target = None
        Cs = set(C)
        for i, pt in enumerate(self.pts):
            if i in asked:
                continue
            if target is not None:
                if len(pt & Cs) == target:
                    return i
            elif C[0] in pt:
                return i
        return None

    def terminal(self, ones, zeros):
        C = self.candidates(ones, zeros)
        r = self.P - len(ones) - len(zeros)
        c = self.a - len(ones)
        if c < 0 or c > r:
            return "inconsistent", C
        if not C:
            return "full", C
        if comb(r, c) == 1:
            return "star" if len(C) == 1 else "inconsistent", C
        return None, C

    def run(self, oracle, max_queries=10 ** 6):
        """Run the procedure; oracle(i)->0/1 answer for address i. Returns (outcome, support_size_or_None, #queries)."""
        ones, zeros = set(), set()
        q = 0
        while True:
            t, C = self.terminal(ones, zeros)
            if t is not None:
                return t, C, q
            i = self.next_query(ones, zeros)
            if i is None or q >= max_queries:
                return "stuck", C, q
            (ones if oracle(i) else zeros).add(i)
            q += 1
