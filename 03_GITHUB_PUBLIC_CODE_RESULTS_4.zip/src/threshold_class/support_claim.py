# Verify: in F(m,j) a hypothesis has proper support iff its positive weight-j set is the avoid(c) star; else full support.
import itertools
from math import comb
def supp(tt,m):
    N=1<<m; s=0
    for i in range(m):
        for y in range(N):
            if ((tt>>y)&1)!=((tt>>(y^(1<<i)))&1): s|=1<<i;break
    return s
for m,j in [(3,1),(4,1),(4,2),(5,2),(5,1),(6,2)]:
    N=1<<m; w=lambda y:bin(y).count('1')
    addr=[y for y in range(N) if w(y)==j]; a=comb(m-1,j)
    base=sum(1<<y for y in range(N) if w(y)>j)
    stars={}
    for c in range(m):
        stars[frozenset(y for y in addr if not y>>c&1)]=c
    bad=0;cnt=0
    for S in itertools.combinations(addr,a):
        tt=base|sum(1<<y for y in S); s=supp(tt,m); cnt+=1
        exp=((1<<m)-1)&~(1<<stars[frozenset(S)]) if frozenset(S) in stars else (1<<m)-1
        if s!=exp: bad+=1
    print(m,j,"hypotheses",cnt,"mismatches",bad)
