"""Noisy-oracle experiments for Theorem 2: adaptive procedure vs truth-table learning vs random-order certificate.
Each address is read n times through a symmetric flip channel (flip prob eta) and the majority is used."""
import random, sys, csv
from math import comb
from oracle1a import Class1A

def noiseless_costs(m, j, trials=2000, seed=1):
    cl = Class1A(m, j); rng = random.Random(seed)
    # worst case of procedure
    worst = 0
    for c in range(m):
        tv = cl.star(c)
        out, C, q = cl.run(lambda i: tv[i]); assert out == "star" and C == [c]; worst = max(worst, q)
    fs = [cl.random_full_support(rng) for _ in range(50)]
    for tv in fs:
        out, C, q = cl.run(lambda i: tv[i]); assert out == "full"; worst = max(worst, q)
    # random-order certificate baseline for a star function
    tot = 0
    for _ in range(trials):
        c = rng.randrange(m); tv = cl.star(c); order = list(range(cl.P)); rng.shuffle(order)
        ones, zeros = set(), set(); q = 0
        for i in order:
            (ones if tv[i] else zeros).add(i); q += 1
            t, C = cl.terminal(ones, zeros)
            if t is not None: break
        tot += q
    return cl, worst, tot / trials

def noisy_success(m, j, eta, n, trials, seed):
    cl = Class1A(m, j); rng = random.Random(seed)
    ok = 0; reads = 0
    for t in range(trials):
        if t % 2 == 0:
            c = rng.randrange(m); tv = cl.star(c); truth = ("star", [c])
        else:
            tv = cl.random_full_support(rng); truth = ("full", [])
        def oracle(i):
            flips = sum(rng.random() < eta for _ in range(n))
            val = tv[i] ^ (1 if flips * 2 > n else 0)      # majority of n readings (n odd)
            return val
        out, C, q = cl.run(oracle)
        reads += q * n
        if out == truth[0] and C == truth[1]:
            ok += 1
    return ok / trials, reads / trials

if __name__ == "__main__":
    rows = []
    print("Noiseless costs")
    for (m, j) in [(5, 2), (6, 2), (7, 2), (7, 3), (8, 2), (8, 3), (9, 3), (9, 4), (10, 3)]:
        cl, worst, rnd = noiseless_costs(m, j)
        print(f"m={m} j={j}: T={cl.T} procedure_worst={worst} truth_table={cl.P} mean_random_order_certificate={rnd:.1f}")
        rows.append(dict(kind="noiseless", m=m, j=j, T=cl.T, procedure_worst=worst, truth_table=cl.P, random_order=round(rnd, 2)))
    print("Noisy success (m=7,j=3; T=17; truth-table reads = 35 n)")
    for eta in (0.05, 0.10, 0.20):
        for n in (1, 3, 5, 7, 9, 11, 15, 21):
            s, r = noisy_success(7, 3, eta, n, 1500, seed=int(1000 * eta) + n)
            tt_fail_per_addr = sum(comb(n, i) * eta ** i * (1 - eta) ** (n - i) for i in range((n + 1) // 2, n + 1))
            tt_success = (1 - tt_fail_per_addr) ** 35
            print(f"eta={eta} n={n}: adaptive success={s:.3f} mean reads={r:.0f}; truth-table (35 addresses, n reads each) success~{tt_success:.3f} reads={35*n}")
            rows.append(dict(kind="noisy", m=7, j=3, eta=eta, n=n, adaptive_success=round(s, 4), adaptive_reads=round(r, 1),
                             truth_table_success=round(tt_success, 4), truth_table_reads=35 * n))
    keys = sorted({k for r in rows for k in r})
    with open("noisy_1a_results.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys); w.writeheader(); w.writerows(rows)
