# Threshold-profile class F(m,j) (Theorem 2, Supplement Appendices B and C)

| File | Purpose |
|---|---|
| `thm2_game.cpp` | Exhaustive game search for the exact adaptive minimax cost on F(m,j). Hypotheses are all subsets of the C(m,j) weight-j addresses with C(m-1,j) positive members; a state is terminal when all consistent hypotheses share one support. Build with `g++ -O2 -o thm2_game thm2_game.cpp`, run `./thm2_game m j`. Addresses are stored in a 32-bit mask, so C(m,j) must be at most 32. |
| `support_claim.py` | Direct check from truth tables that a hypothesis has proper support exactly when its positive set is the set of addresses avoiding one control (Lemma B1), for (m,j) in {(3,1),(4,1),(5,1),(4,2),(5,2),(6,2)}. |
| `procedure1a_128.cpp`, `procedure1a.cpp` | Run the explicit candidate-elimination procedure of Appendix B against every answer sequence and report its worst-case query count and any identification error (`./procedure1a_128 m j`). |
| `oracle1a.py`, `exp_noisy_1a.py` | Noiseless costs and the symmetric-flip noise simulation of Appendix C (Table S1, Figure S1). `results/noisy_1a_results.csv` holds the output. |

Reproduced values (minimax equals T(m,j) = C(m-1,j-1) + ceil((m-1)/j)):

| (m,j) | (5,2) | (6,2) | (7,2) | (8,2) |
|---|---|---|---|---|
| exhaustive search | 6 | 8 | 9 | 11 |

One below T: (4,2) gives 4 and j=1 gives m-1 for m=3,4,5, which is why the theorem requires j >= 2 and m >= 2j+1. The explicit procedure matches T for all twelve pairs of Table 6, for example (9,4) gives 58. Run time on one core is under a minute up to (7,2) and a few minutes for (8,2), which visits about 7 x 10^7 states and needs about 2 GB of memory.
