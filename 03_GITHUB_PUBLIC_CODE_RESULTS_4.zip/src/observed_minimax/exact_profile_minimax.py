import os
#!/usr/bin/env python3
"""Exact worst-case adaptive labelled-support recovery for small sector profiles.
Candidate pool is ALL Boolean truth tables with the specified Hamming-layer counts,
not just the node rule recorded in the corpus. Zero error, q-capped queries.
"""
import itertools, functools, json, csv, io, zipfile
from collections import defaultdict
from pathlib import Path
ARCHIVE=os.environ.get('DG_ARCHIVE','boolean-support-identification_PUBLIC_AUDITED.zip')

def hyp(m,A):
    layers=[[x for x in range(1<<m) if x.bit_count()==j] for j in range(m+1)]
    ans=[]
    for subsets in itertools.product(*(itertools.combinations(layer,a) for layer,a in zip(layers,A))):
        mask=sum(1<<x for layer in subsets for x in layer)
        supp=0
        for i in range(m):
            if any(((mask>>x)^(mask>>(x^(1<<i))))&1 for x in range(1<<m)):
                supp|=1<<i
        ans.append((mask,supp))
    return ans

def exact(m,A,q):
    H=hyp(m,A);n=len(H)
    if n>30:return {'n':n,'status':'too_large_for_current_exhaustive_dp'}
    qu=[x for x in range(1<<m) if x.bit_count()<=q]
    qm=[sum(1<<i for i,(table,_) in enumerate(H) if table>>x&1) for x in qu]
    sm=defaultdict(int)
    for i,(_,support) in enumerate(H):sm[support]|=1<<i
    @functools.lru_cache(None)
    def solve(state):
        if any(state&~s==0 for s in sm.values()):return 0
        best=10000
        for mask in qm:
            a=state&mask;b=state&~mask
            if not a or not b:continue
            # Bound from remaining guesses not necessary, small k.
            cost=1+max(solve(a),solve(b))
            if cost<best:best=cost
        return best
    v=solve((1<<n)-1)
    return {'n':n,'cost':None if v==10000 else v,'support_sizes':sorted(set(s.bit_count() for _,s in H)), 'distinct_supports':len(sm),'states':solve.cache_info().currsize,'q':q}

import sys
CSV=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[2]/'k6'/'baseline'/'results'/'real_networks_nodes.csv'
rows=list(csv.DictReader(open(CSV,newline='')))
ps=defaultdict(list)
for r in rows:
    if int(r['k'])==3 and int(r['nsizes'])>1:
        ps[tuple(map(int,r['profile'].split()))].append(r['model']+'/'+r['node'])
out=[]
for A,occ in sorted(ps.items()):
    for q in (1,2,3):
        obj=exact(3,A,q);obj['A']=list(A);obj['network_occurrences']=len(occ);obj['example']=occ[0];out.append(obj)
        print(obj)
Path(str(__import__('pathlib').Path(__file__).with_name('exact_m3_results.json'))).write_text(json.dumps(out,indent=2,ensure_ascii=False))
