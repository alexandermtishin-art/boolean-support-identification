# Reproduction of exact support recovery on observed profiles

Run `python exact_profile_minimax.py [path/to/real_networks_nodes.csv]` to enumerate all compatible truth tables for the observed three-input profiles and compute exact adaptive minimax costs by memoized recursion (default input: `k6/baseline/results/real_networks_nodes.csv`). Run `python crosscheck_m3.py` for the independent three-input check and `python independent_m4_crosscheck.py` for a separately implemented bottom-up enumeration of the two four-input profiles.

The inputs are public Boolean-network rules used only to select observed sector profiles. The minimax calculations enumerate ALL truth tables with each selected profile, not just the published function. Queries have Hamming weight <= q.

Output: `exact_m3_results.json`, `independent_m4_results.json`, `independent_crosscheck.json`. `minimax` null (or nonfinite in the top-down intermediate output) means identification is impossible under that cap.

The two solvers are separately implemented but authored in the same research process; this is an implementation cross-check, not independent external peer verification.
