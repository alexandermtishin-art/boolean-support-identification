# Release candidate notes — 2026-10-22

- Source and certificate paths are directly browsable; no nested ZIP required.
- 14-query tree for n=5 and 147 archived tasks included.
- Added corpus-matched null-model outputs and separate support-spectrum audit tables.
- Included the completed depth-12 Colab run artifacts: independently validated depth-12 decision tree and the original exhaustive-search statuses (depth 10 NO, depth 11 NO, depth 12 YES_VERIFIED). V3 is the computation notebook, not a second independent exhaustive run.
- MAIN and SUPPLEMENT DOCX are distributed separately; none are included in this GitHub ZIP.
- Before publishing, review author licensing choices and third-party material provenance.

MAIN and SUPPLEMENT are distributed as separate submission artifacts, not in this GitHub archive.

Depth-12 witness and author-supplied completed depth statuses are now included under `adaptive_n5/`; see `EXACT_DEPTH12_CERTIFICATES.md`.


## Additions of 2026-10-23

- `src/threshold_class/`: exhaustive game search for Theorem 2 (minimax equals T at (5,2), (6,2), (7,2), (8,2); one below T at (4,2) and for j=1), direct check of the star-guard structure, explicit-procedure checks for Table 6, and the noise simulation behind Supplement Table S1.
- `src/exact_certificates/`: input table and outputs for the 20 exact certificates (13 of length 2, six of length 3, one of length 7) and the MILP cross-check; the two scripts now take file paths instead of fixed locations.
- `src/profile_bounds/`: script and table for the bounds on the 53 observed ambiguous profiles (47 unsolved, lower bounds 3 to 10, upper bounds 8 to 8089).
- `adaptive_n5/runs.jsonl` is the journal of the 46 saved checkpoints of the n=5 search (22 Oct 2026, 09:33 to 16:19 UTC; NO at depth 10 and 11, YES at depth 12), with `checkpoint_current.json`, `checkpoint_previous.json`, `search/search_compact.cpp` and `adaptive_n5/check_run_log.py`. The NO statuses come from this one run; independent implementations in `verification/depth11/` confirm NO only up to depth 7 (Python) and depth 5 (C++).
- `src/observed_minimax/exact_profile_minimax.py` reads the node CSV directly; results are in `src/observed_minimax/results/`.

- `src/corpus_ambiguity/structured_null_more.py` and `structured_null_ncf.py`: structured null models (random threshold, read-once and nested canalizing rules, conditioned on all inputs essential). Output of the run used in the paper: `structured_null_more_output.txt` (the `uniform` row is not matched on the number of positive rows and is not used in the paper). Among 1,125 corpus rules with at least three inputs, 1,085 have all inputs essential; 39 of these and 32 of the 40 others are support-size ambiguous.
