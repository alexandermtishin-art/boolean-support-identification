"""Consistency check of the saved Colab run journal against certified_results.json and the solver sources.
Usage: python adaptive_n5/check_run_log.py   (run from the repository root)"""
import json, hashlib, pathlib
here = pathlib.Path(__file__).resolve().parent
root = here.parent
runs = [json.loads(l) for l in open(here / 'runs.jsonl') if l.strip()]
cert = json.load(open(here / 'certified_results.json'))
gens = [r['generation'] for r in runs]
assert gens == list(range(1, len(runs) + 1)), 'generations are not consecutive'
final = {str(r['depth']): r['generation'] for r in runs if r['status'] in ('NO', 'YES')}
for d, v in cert.items():
    assert final[d] == v['checkpoint_generation'], (d, final[d], v)
    stat = [r['status'] for r in runs if r['generation'] == v['checkpoint_generation']][0]
    assert stat == ('NO' if v['status'] == 'NO' else 'YES')
depths = [r['depth'] for r in runs[1:]]
assert depths == sorted(depths), 'depth sequence is not monotone'
assert all(r['stdout_tail'].strip().splitlines()[-1] == r['status'] or r['status'] == 'TEST_CHECKPOINT' for r in runs)
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
orig = sha(root / 'search' / 'search_resumable.cpp')
comp = sha(root / 'search' / 'search_compact.cpp')
assert all(r['source_sha256'] == orig for r in runs), 'source hash mismatch'
assert all(r.get('solver_sha256', comp) == comp for r in runs)
n_orig = sum(1 for r in runs if 'solver_sha256' not in r)
print('journal entries:', len(runs), '| original solver:', n_orig, '| compact solver:', len(runs) - n_orig)
for d in ('10', '11', '12'):
    r = runs[final[d] - 1]
    print('depth', d, cert[d]['status'], 'generation', r['generation'], r['timestamp_utc'])
print(runs[0]['timestamp_utc'], '->', runs[-1]['timestamp_utc'])
print('OK')
