# Depth-12 certificate and depth-10/11 solver results (n=5, adaptive search)

## What is claimed
For the complete class F_5 of 2,250 rules with sector polynomial t^2+2t^3+t^4, no adaptive decision tree of depth 11 identifies the support, and a tree of depth 12 does. The adaptive minimax cost is therefore 12. A tree of depth at most 9 is also a tree of depth 10, so the NO at depths 10 and 11 covers every smaller depth.

## Evidence in this package
| Item | File | Status |
|---|---|---|
| Depth-12 tree (SHA-256 `07f97bcde9bc5e1b4a63187d3fec366ceb29188feb5be9beac7ba7b153063a9f`) | `adaptive_n5/tree_depth12.json` | Checked independently on all 2,250 rules (`verification/depth12/verify_colab_result.py`, log in `adaptive_n5/depth12_independent_verification.log`) |
| Final statuses | `adaptive_n5/certified_results.json` | depth 10 NO (generation 6), depth 11 NO (generation 25), depth 12 YES (generation 46) |
| Run journal, 46 generations | `adaptive_n5/runs.jsonl` | One line per saved checkpoint with UTC time, depth, status, size, SHA-256 of the memo file and the tail of the solver output |
| Last two checkpoints | `adaptive_n5/checkpoint_current.json`, `checkpoint_previous.json` | Metadata of generations 46 and 45 |
| Solvers | `search/search_resumable.cpp` (generations 1 to 41), `search/search_compact.cpp` (generations 42 to 46) | The SHA-256 values in the journal match these files; the notebooks in `search/` embed the same sources |

`python adaptive_n5/check_run_log.py` checks that the journal is consecutive, that depth never decreases, that the three final statuses and generation numbers agree with `certified_results.json`, and that the recorded source hashes match the two solver files.

## What the journal shows
The search ran on Google Colab on 22 October 2026 from 09:33 to 16:19 UTC. Depth 10 finished with NO at 09:50, depth 11 with NO at 11:38, and depth 12 with YES at 16:19, after a run of resumable three-minute slices. The memo table is keyed by the pair (state, remaining depth), so entries computed for one depth are valid at another. Generations 1 to 41 used `search_resumable.cpp`, which produced both NO results. Generations 42 to 46 used `search_compact.cpp` with the same memo format, and produced the YES, whose tree was then verified independently.

## What is not claimed
The NO results come from this single run of the author's solver. They have not been reproduced by a second implementation beyond depth 7 (Python, `verification/depth11/independent_dp.py`) and depth 5 (C++, `independent_cpp.cpp`). The memo files of about 1.3 to 2.4 GB are not included. The run took about seven hours of wall-clock time, and the memo file grew to 2.4 GB on disk.
