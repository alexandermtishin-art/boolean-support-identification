# Full 3,181-node matched-null calibration

Source: `real_networks_nodes.csv` embedded in `IS_GITHUB_REPRODUCIBILITY_STAGING_2026-10-22.zip`. Per-node arity k, sector profile, total positives b, and cardinality-support ambiguity come from that source. Unit of analysis: node occurrences (not distinct truth tables).

- k <= 4: N=2778, observed 24; exact expected 17.75173, earlier exhaustive calculation.
- k=5,6: N=286, observed 25; exact expected 9.52549737, new independent profile enumeration.
- k=7,...,14: N=117, observed 22; null expectation between 0 and 4.49542819 (rigorous conservative upper bound).
- Whole corpus: N=3181, observed 71; expected between 27.277227 and 31.772656.

For k=5,6, enumerate all profiles P=(p_0,...,p_k) admitting at least one inessential coordinate by generating Q at k-1 variables and forming P=(1+t)Q. For each candidate P, determine all possible essential-support sizes by inclusion-exclusion. If Q_r=P/(1+t)^r is a valid sector profile, the number of functions on k-r variables with *all* coordinates essential is

`sum_{s=0}^{k-r} (-1)^s binom(k-r,s) prod_j binom(binom(k-r-s,j), [t^j]Q_r/(1+t)^s)`;

invalid coefficient vectors contribute zero. The number of k-variable functions with profile P is `prod_j binom(binom(k,j),p_j)`. Sum this count over profiles admitting at least two distinct essential-support sizes, group by b, then divide by `binom(2^k,b)`. This method's k=4 exact probabilities reproduce all 16 k=4 strata from the earlier exhaustive truth-table enumeration.

For higher k, a profile with any inessential coordinate must be divisible by (1+t), so P(-1)=0. With N=2^(k-1) even- and N odd-weight addresses, uniformly choosing b positives gives probability zero if b is odd, and `binom(N,b/2)^2 / binom(2N,b)` if b is even. This is an upper bound, **not** the exact ambiguity probability: P(-1)=0 need not imply valid profile division or two possible support sizes. The lower bound 0 is deliberately conservative.

Observations from distinct networks are not independent. The null does not condition on the publication process or the preselection of essential inputs. No p-value or causal conclusion is claimed, and physical cost savings do not follow.

Reproduce: run `python extend_null.py` after placing the public-staging ZIP at the hard-coded path documented in its first lines; `matched_k_ge5.csv` and `summary_by_k.csv` are outputs. Low-arity comparison uses `matched_k_le4.csv` from the preceding study.
