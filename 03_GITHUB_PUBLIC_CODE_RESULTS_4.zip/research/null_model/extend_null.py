import csv,io,zipfile,collections,math,itertools,functools
from pathlib import Path
from fractions import Fraction
OUT=Path('/mnt/data/IS_CLAUDE_STEP8_FULL_NULL')
with zipfile.ZipFile('/mnt/data/IS_GITHUB_REPRODUCIBILITY_STAGING_2026-10-22.zip') as z:
 p=next(q for q in z.namelist() if q.endswith('real_networks_nodes.csv'))
 rows=list(csv.DictReader(io.StringIO(z.read(p).decode())))
for x in rows:
 x['k']=int(x['k']);x['b']=sum(map(int,x['profile'].split()));x['obs']=int(int(x['nsizes'])>1)
C=math.comb
@functools.lru_cache(maxsize=None)
def compatible(p,r):
 q=list(p)
 for _ in range(r):
  n=len(q)-1
  nxt=[q[0]]
  for j in range(1,n):nxt.append(q[j]-nxt[-1])
  if q[-1]!=nxt[-1] or any(v<0 or v>C(n-1,j) for j,v in enumerate(nxt)):
   return None
  q=nxt
 return tuple(q)
@functools.lru_cache(maxsize=500000)
def total_count(p):
 n=len(p)-1
 t=1
 for j,v in enumerate(p):
  if v<0 or v>C(n,j):return 0
  t*=C(C(n,j),v)
 return t

def full_count(q):
 m=len(q)-1
 # inclusion-exclusion on labelled inessential coordinates
 ans=0
 for r in range(m+1):
  reduced=compatible(q,r)
  if reduced is not None:
   term=C(m,r)*total_count(reduced)
   ans+=(-1 if r%2 else 1)*term
 return ans

def is_amb(p):
 k=len(p)-1
 sizes=0
 for r in range(k+1):
  q=compatible(p,r)
  if q is not None and full_count(q)>0:
   sizes+=1
   if sizes>1:return True
 return False

def exact_strata(k):
 caps=[C(k,j) for j in range(k+1)]
 # only profiles with at least one inessential coordinate can be size-ambiguous
 # generate base truth tables by their profiles on k-1 coords, add (1+t), unique profiles
 sub_caps=[C(k-1,j) for j in range(k)]
 seen=set()
 for q in itertools.product(*(range(v+1) for v in sub_caps)):
  p=(q[0],)+tuple(q[j-1]+q[j] for j in range(1,k))+(q[-1],)
  seen.add(p)
 total=collections.Counter()
 for p in seen:
  if is_amb(p):total[sum(p)]+=total_count(p)
 print('k',k,'candidate profiles',len(seen),'ambiguous strata',len(total),flush=True)
 return total

def upper(k,b):
 if b%2:return Fraction(0)
 a=1<<(k-1)
 if b//2>a:return Fraction(0)
 return Fraction(C(a,b//2)**2,C(a*2,b))

exact={}
for k in (5,6):exact[k]=exact_strata(k)
records=[]
for x in rows:
 k,b=x['k'],x['b']
 if k<=4:continue
 up=upper(k,b)
 if k in exact:
  prob=Fraction(exact[k].get(b,0),C(1<<k,b))
  method='EXACT'
 else:
  prob=None;method='UPPER_BOUND'
 records.append({'model':x['model'],'node':x['node'],'k':k,'b':b,'observed_size_ambiguous':x['obs'],
 'p_exact':float(prob) if prob is not None else '', 'p_upper':float(up),'method':method})
with open(OUT/'matched_k_ge5.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
by=collections.defaultdict(list)
for r in records:by[r['k']].append(r)
with open(OUT/'summary_by_k.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow(['k','n','observed','expected_exact_or_lower','expected_upper','exact'])
 for k,v in sorted(by.items()):
  lo=sum(float(q['p_exact']) for q in v if q['p_exact']!='')
  hi=sum(float(q['p_upper']) if q['p_exact']=='' else float(q['p_exact']) for q in v)
  w.writerow([k,len(v),sum(q['observed_size_ambiguous'] for q in v),lo,hi,all(q['p_exact']!='' for q in v)])
  print(k,len(v),sum(q['observed_size_ambiguous'] for q in v),lo,hi,flush=True)
print('summary',sum(r['observed_size_ambiguous'] for r in records),sum(float(r['p_exact']) for r in records if r['p_exact']!=''),sum(float(r['p_upper']) if r['p_exact']=='' else float(r['p_exact']) for r in records),flush=True)
