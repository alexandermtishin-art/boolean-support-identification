# Boolean support identification — reproducibility package

Public research code and calculations accompanying *Exact Support Identification of Boolean Guards from Sector Counts and Weight-Limited Queries*. The MAIN manuscript and SUPPLEMENT are distributed **separately**, not in this package.

## Directory guide

- `src/`: baseline algorithms and original model/code; `src/threshold_class/` (Theorem 2 game search, procedure checks, noise simulation), `src/exact_certificates/` (exact certificates for 20 small rules), `src/profile_bounds/` (bounds for the 53 corpus profiles)
- `proofs/`: mathematical derivations and finite witness checks
- `adaptive_n5/`: saved depth-12 and depth-14 trees, depth-12 verification log, and solver depth statuses
- `search/`: resumable C++ solver and Colab notebooks, including compact V2 and overnight V3
- `verification/depth11/`: independent Python/C++ attempts at a depth-11 lower bound, clearly distinguished from completed original search
- `verification/depth12/`: read-only depth-12 tree verification
- `verification/stress/`, `verification/spectra/`, `verification/null_model/`: additional checks and matched-corpus tests
- `k6/`: 147 capped-certificate verification tasks and data
- `experimental/`, `research/`: derivative research data and analysis

## Immediate verification

```bash
python verification/depth12/verify_colab_result.py adaptive_n5
python adaptive_n5/check_run_log.py
python proofs/verify_nonadaptive_witnesses.py
python src/threshold_class/support_claim.py
python src/exact_certificates/exact_certificates_small.py && python src/exact_certificates/independent_milp_verify.py
python src/profile_bounds/compute_profile_bounds.py
python src/corpus_ambiguity/structured_null_more.py k6/baseline/results/real_networks_nodes.csv 1000 5
```

The Theorem 2 game search is built with `g++ -O2 -o thm2_game src/threshold_class/thm2_game.cpp` and run as `./thm2_game 8 2` (see `src/threshold_class/README.md`).

The depth-12 tree is included and independently verified on all 2,250 functions; consult `EXACT_DEPTH12_CERTIFICATES.md` for provenance and the status of negative-search results.

Read `EXACT_DEPTH12_CERTIFICATES.md`, `REPRODUCIBILITY_LIMITATIONS.md`, and `DATA_PROVENANCE.md` before citing computation or laboratory data. No third-party dataset redistribution rights are implied.


Note: `adaptive_n5/tree_depth14.json` and `verify_saved_tree.py` are an earlier depth-14 certificate kept for history. The result used in the paper is the depth-12 tree.

Note on checksums: `src/exact_certificates/results/exact_certificates_k3_k4.csv` and `summary.json` contain wall-clock runtime columns, so regenerating them changes their SHA-256 values while every certificate is unchanged.
