# Checks

From repository root:

```bash
python verification/depth12/verify_colab_result.py adaptive_n5
python adaptive_n5/check_run_log.py
python proofs/verify_nonadaptive_witnesses.py
python verification/stress/test_conflict_pairs.py
```

For the **included** depth-12 witness:

```bash
python verification/depth12/verify_colab_result.py adaptive_n5
```

The historical negative-depth search is a completed result of the published search implementation; its logs are not an independently checked proof artifact. Do not interpret a status file by itself as a certificate. See `EXACT_DEPTH12_CERTIFICATES.md`.

Completed depth-12 tree and depth 10/11 negative statuses are included under `adaptive_n5/`; see `EXACT_DEPTH12_CERTIFICATES.md`.
