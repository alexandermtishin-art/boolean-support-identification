# Exact support identification from Hamming-layer profiles — reproducibility package

**Research artifact, version 2026-10-22.** Associated with the manuscript *Exact Support Identification of Boolean Guards from Sector Counts and Weight-Limited Queries* (Information Sciences submission preparation).

This is a **public-code staging package**, not an assertion that the manuscript has been accepted or all computational claims independently certified. It separates exact theorem checks, empirical outputs, and an ongoing unresolved optimization.

## Quick reproducibility checks

Requirements: Python 3.10+ (standard library for first two checks), C++17 compiler for native tools. Other scripts may require NumPy/SciPy and source datasets.

```bash
python adaptive_n5/verify_saved_tree.py
python proofs/verify_nonadaptive_witnesses.py
```

The first check verifies a concrete depth-14 adaptive decision tree for all 2,250 Boolean functions with profile `(0,0,1,2,1,0)`. The second checks finite conflicting-pair witnesses for the nonadaptive lower bound for n=5–8; it is not itself a full formal proof of the asymptotic theorem (see `proofs/THEOREM_C.md`).

## Directory map

- `src/` — historical baseline code, exact certificate tests, observed-profile minimax, and corpus summaries.
- `k6/` — independent capped-certificate reproduction outputs (147 jobs, not a proof of global heuristic optimality). Input network corpus is **not mirrored** here pending a source-by-source redistribution check.
- `adaptive_n5/` — machine-readable depth-14 tree and independent deterministic verifier.
- `proofs/` — analytic infinite-family proof text, finite witness verifier, tabulated bounds.
- `experimental/` — derived tables and an interpretation/limitations report. Original third-party lab data are **not redistributed**; retrieve them from the cited papers and supplements.
- `search/` — work-in-progress Colab and C++ exact search for the n=5 adaptive optimum. The latest completed Colab depth-10 status is NO; depth 11 is in progress. The uploaded Colab log and multi-hundred-MiB memo are not bundled. **Do not claim Q_A(5) is known exactly.**

## Scope and caveats

- `Q_NA(5)=22` and the independently checkable depth-14 tree are separate claims from the open exact adaptive minimum.
- Data-derived binary classifications depend on chosen experimental thresholds; they are not physical measurement savings.
- Archived research code may contain machine-specific assumptions; inspect before running full historical pipelines.
- Some source datasets have separate licenses; this repository intentionally contains no raw third-party network or wet-lab dataset.
- Repository license for original research code **not yet selected**; a license decision is needed before unrestricted reuse claims.

## Suggested citation

Cite the manuscript and this repository at the tagged release/commit once published. Add a Zenodo DOI only after creating a verified release.
