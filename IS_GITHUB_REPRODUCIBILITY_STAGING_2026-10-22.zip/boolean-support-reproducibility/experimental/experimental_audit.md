# Experimental validation audit — Information Sciences

## Verified BLADE calculation
{
  "n_design_output_functions": 226,
  "n_circuits": 113,
  "design_profile_ambiguity": 52,
  "same_support_across_thresholds": 158,
  "match_30": 210,
  "support_30": 220,
  "match_50": 161,
  "support_50": 181,
  "match_70": 121,
  "support_70": 159
}

Binary measurements computed from published circuit/output means at exploratory thresholds of 0.30, 0.50 and 0.70 of within-channel maximum. These are **not externally calibrated assay cutoffs**. 113 distinct designs, 226 output functions. This demonstrates retrospective application, not reduced measurement cost.

## Gorochowski RNA-seq YFP
Input is Dataset EV1, triplicate YFP FPKM for eight tube states. Means by tube: 158.937, 128.522, 19581.796, 21832.624, 24455.477, 832.380, 3596.119, 3267.051.

The largest adjacent ordered mean ratio is 5.445; its geometric midpoint defines an *exploratory data-derived* threshold of 8391.572 FPKM. Calls in supplied Tube order: 00111000, 3 ON of 8. All three replicates unanimously agree with the corresponding mean call: True. Calls are not justified as using author-specified experimental threshold.

**Crucial unresolved metadata:** tube label cannot be mapped from these supplied materials to a fixed triple (IPTG,aTc,arabinose) without further evidence. Thus the Hamming profile is not inferable from Tube ordering. **However, for this observed 3-ON/5-OFF pattern, every possible assignment of the ON values to three-bit addresses has essential support {1,2,3}: the full support is permutation-invariant.** There are 12 possible Hamming profiles across unknown state permutations but exactly 1 possible essential support. This is a genuine three-input experimental support result conditional on the exploratory binary threshold, not a validation of the particular profile or adaptive minimax query cost. Do not choose a mapping by sorting means, or claim source-verified Hamming profiles.

## LacI/GalR
Supplement provides plotted GFP/OD and replicate error bars, not machine-readable per-condition readings. We do not fabricate numeric output. Study remains an independent qualitative check for three/four-input logic, but not a quantitative replication under our method.

## Publication-safe decision
Two independent physical experiments provide quantitative material; only BLADE supports unambiguous state-labeled Boolean profiles at this time. RNA-seq yields the complete three-variable essential support for YFP, regardless of the unknown tube-to-address mapping, because exactly three of eight states are ON; its specific Hamming profile remains undetermined. A full three-experiment retrospective support-identification test remains uncompleted. **Issue #5 may be closed only as motivation and applicability of retrospective analysis in BLADE; it is not a cross-platform experimental verification of the minimax theorem or measurement cost saving.**

Reproducibility: `finalize_exp.py` alongside original uploaded XLSX and `experimental_support_analysis.py`, and prior `blade_analysis.csv`.
