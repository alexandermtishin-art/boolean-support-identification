# Data provenance and redistribution

Original laboratory materials: Shis et al. (ACS Synthetic Biology, 2014), Gorochowski et al. (Molecular Systems Biology, 2017), and Weinberg et al. (Nature Biotechnology, 2017). Data tables in `experimental/` are research-derived analysis outputs, not original author-provided raw data. Refer to the publishers' original supplementary files for measurements, replicate definitions, and reuse permissions.

Network corpus: Cell Collective/CANA-derived datasets are used by historical scripts and require checking individual source redistribution rights before mirroring. Raw network models deliberately excluded from this public draft.

Computational source: files assembled from dated research audit packages (2026-10-21 to 2026-10-22); outputs are not all independently regenerated during packaging.
