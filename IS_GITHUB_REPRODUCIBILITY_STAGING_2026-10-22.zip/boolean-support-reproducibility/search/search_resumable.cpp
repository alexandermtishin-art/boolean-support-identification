#include <bits/stdc++.h>
using namespace std;
using U=uint64_t;
static constexpr int NW=36;
using Mask=array<U,NW>;
vector<unsigned> qs; vector<uint32_t> funcs; vector<unsigned> supports; Mask Q[25],S[32];
unordered_map<U, uint8_t> memo;
long long nodes=0, hits=0; chrono::steady_clock::time_point start;
bool limit=false;
const string cachefile = getenv("IS_CACHE_FILE") ? getenv("IS_CACHE_FILE") : "memo.bin";
void loadmemo(){ifstream in(cachefile,ios::binary); if(!in)return; U k;uint8_t v;while(in.read((char*)&k,sizeof(k))&&in.read((char*)&v,sizeof(v)))memo[k]=v;}
void savememo(){ofstream out(cachefile+".tmp",ios::binary|ios::trunc);for(auto &[k,v]:memo){out.write((char*)&k,sizeof(k));out.write((char*)&v,sizeof(v));} out.close(); rename((cachefile+".tmp").c_str(),cachefile.c_str());}

int countbits(const Mask &a){int n=0; for(U x:a)n+=__builtin_popcountll(x);return n;}
bool intersects(const Mask&a,const Mask&b){for(int i=0;i<NW;i++)if(a[i]&b[i])return true;return false;}
void AND(Mask &a, const Mask&b){for(int i=0;i<NW;i++)a[i]&=b[i];}
int labelcount(const Mask&a){int c=0;for(int i=0;i<32;i++)if(intersects(a,S[i]))c++;return c;}
int popc(unsigned x){return __builtin_popcount(x);}
int supp(uint32_t v){int m=0;for(int k=0;k<5;k++){bool diff=false;for(int x=0;x<32;x++)if(!(x&(1<<k))){if(((v>>x)&1)!=((v>>(x^(1<<k)))&1)){diff=true;break;}}if(diff)m|=1<<k;}return m;}
static inline U key(unsigned yes,unsigned no,int d){return U(yes) | (U(no)<<25) | (U(d)<<50);}
struct Opt{int score,cnts,query; Mask a,b;};
bool solve(const Mask&state,unsigned yes,unsigned no,int d){
 nodes++;
 if(nodes%4096==0){auto ms=chrono::duration_cast<chrono::milliseconds>(chrono::steady_clock::now()-start).count();if(ms>(getenv("IS_SLICE_MS") ? atol(getenv("IS_SLICE_MS")) : 120000L)){limit=true;return false;}}
 int c=labelcount(state);if(c<=1)return true; if(d==0 || c>(1<<d))return false;
 U k=key(yes,no,d);auto it=memo.find(k);if(it!=memo.end()){hits++;return it->second;}
 vector<Opt> op;unsigned taken=yes|no;
 for(int i=0;i<25;i++)if(!(taken&(1u<<i))){
  Mask a,b;bool na=false,nb=false;for(int w=0;w<NW;w++){a[w]=state[w]&Q[i][w]; b[w]=state[w]&~Q[i][w];na|=(a[w]!=0);nb|=(b[w]!=0);} if(!na||!nb)continue;
  int ca=labelcount(a),cb=labelcount(b);if(max(ca,cb)>(1<<(d-1)))continue;
  int z=max(countbits(a),countbits(b));int score=max(ca,cb)*100000+z;
  op.push_back({score,z,i,a,b});
 }
 sort(op.begin(),op.end(),[](const Opt&a,const Opt&b){return a.score<b.score;});
 for(auto &o:op){
  if(solve(o.a,yes|(1u<<o.query),no,d-1)&&solve(o.b,yes,no|(1u<<o.query),d-1)){memo[k]=1;return true;}
  if(limit)return false;
 }
 memo[k]=0;return false;
}
string treejson(const Mask&state,unsigned yes,unsigned no,int d){
 int c=labelcount(state);if(c==1){for(int i=0;i<32;i++)if(intersects(state,S[i]))return string("{\"support\":")+to_string(i)+"}";}
 unsigned taken=yes|no;
 for(int i=0;i<25;i++)if(!(taken&(1u<<i))){
  Mask a{},b{};bool na=false,nb=false;
  for(int w=0;w<NW;w++){a[w]=state[w]&Q[i][w];b[w]=state[w]&~Q[i][w];na|=(a[w]!=0);nb|=(b[w]!=0);}
  if(!na||!nb)continue;
  if(solve(a,yes|(1u<<i),no,d-1)&&solve(b,yes,no|(1u<<i),d-1)){
   return string("{\"query\":")+to_string(qs[i])+",\"zero\":"+treejson(b,yes,no|(1u<<i),d-1)+",\"one\":"+treejson(a,yes|(1u<<i),no,d-1)+"}";
  }
 }
 throw runtime_error("tree reconstruction failed");
}
int main(int argc,char**argv){int d=argc>1?atoi(argv[1]):9;
 for(int i=0;i<32;i++)if(popc(i)>=2&&popc(i)<=4)qs.push_back(i);
 vector<int> L[5];for(int i=0;i<32;i++)if(popc(i)>=2&&popc(i)<=4)L[popc(i)].push_back(i);
 for(int a:L[2])for(int bi=0;bi<(int)L[3].size();bi++)for(int ci=bi+1;ci<(int)L[3].size();ci++)for(int z:L[4]){uint32_t v=(1u<<a)|(1u<<L[3][bi])|(1u<<L[3][ci])|(1u<<z);funcs.push_back(v);supports.push_back(supp(v));}
 Mask all{};for(int j=0;j<(int)funcs.size();j++){all[j/64]|=1ull<<(j%64);S[supports[j]][j/64]|=1ull<<(j%64);for(int i=0;i<25;i++)if((funcs[j]>>qs[i])&1)Q[i][j/64]|=1ull<<(j%64);}
 loadmemo(); start=chrono::steady_clock::now();
 cout<<"functions "<<funcs.size()<<" depth "<<d<<endl;
 for(int weight=2;weight<=4;weight++){
  int q=0;while(popc(qs[q])!=weight)q++;
  Mask a,b;for(int j=0;j<NW;j++){a[j]=all[j]&Q[q][j];b[j]=all[j]&~Q[q][j];}
  cout<<"root "<<weight<<" start"<<endl;
  bool ans=solve(a,1u<<q,0,d-1)&&solve(b,0,1u<<q,d-1);
  cout<<"root "<<weight<<" result "<<ans<<" nodes "<<nodes<<" memo "<<memo.size()<<" hits "<<hits<<" elapsed "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;
  if(ans){ofstream tree("tree.json");tree<<"{\"query\":"<<qs[q]<<",\"zero\":"<<treejson(b,0,1u<<q,d-1)<<",\"one\":"<<treejson(a,1u<<q,0,d-1)<<"}";tree.close();savememo();cout<<"YES"<<endl;return 0;}
  if(limit){savememo();cout<<"UNKNOWN"<<endl;return 2;}
 }
 savememo();cout<<"NO"<<endl;
}
