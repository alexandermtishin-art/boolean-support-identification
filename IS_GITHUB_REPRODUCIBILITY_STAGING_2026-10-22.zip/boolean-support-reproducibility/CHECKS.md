# Minimal public smoke tests

Run `python adaptive_n5/verify_saved_tree.py` to verify a fixed decision-tree certificate, not just rerun a tree-building heuristic.
Run `python proofs/verify_nonadaptive_witnesses.py` to enumerate finite pair witnesses. The proof of all n is in `proofs/THEOREM_C.md`.
The historical k6 job set can be rerun from `k6/verify_k6_independent.py` **after retrieving the separately sourced network corpus** and placing it in its expected data directory; the bundled outputs are archival and should not be represented as a fresh run.
