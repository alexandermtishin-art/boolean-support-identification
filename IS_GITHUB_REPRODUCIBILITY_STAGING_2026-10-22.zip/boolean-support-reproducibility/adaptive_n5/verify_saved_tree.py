from itertools import combinations
from collections import Counter
import json, pathlib
p=pathlib.Path(__file__).resolve().parent
layers={w:[x for x in range(32) if x.bit_count()==w] for w in (2,3,4)}
def support(pos):
 mask=sum(1<<x for x in pos);s=0
 for i in range(5):
  if any(((mask>>x)&1)!=((mask>>(x^(1<<i)))&1) for x in range(32) if not x&(1<<i)):s|=1<<i
 return s
fs=[(frozenset((a,b,c,d)),support((a,b,c,d))) for a in layers[2] for b,c in combinations(layers[3],2) for d in layers[4]]
tree=json.loads((p/'tree_depth14.json').read_text())
def classify(node,pos):
 depth=0
 while 'query' in node:
  node=node['one'] if node['query'] in pos else node['zero'];depth+=1
 return node['support'],depth
bad=[];depth=0
for i,(pos,s) in enumerate(fs):
 pred,d=classify(tree,pos);depth=max(depth,d)
 if pred!=s:bad.append(i)
assert len(fs)==2250 and not bad,(len(fs),bad[:10]); assert depth<=14,depth
print('PASS 2250/2250, maximum depth',depth,'distinct supports',len(set(s for _,s in fs)))
