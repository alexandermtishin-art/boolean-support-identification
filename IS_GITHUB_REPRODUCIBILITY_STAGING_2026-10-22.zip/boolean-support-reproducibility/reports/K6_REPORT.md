# Independent capped-certificate reproduction — 2026-10-21

## Outcome

**147/147 capped-certificate jobs independently recomputed**, using a newly written exact alternative-witness feasibility checker rather than the archive's MILP evaluator. **Zero mismatches** against the archived per-instance output. **All 14 rows of Table 4** (counts and rounded means) match. Small randomly chosen instances for k=3,4,5 were cross-checked against original SciPy MILP: PASS.

## Mathematical method

For a candidate certificate Q and Hamming-layer profile A, each coordinate i is tested for existence of an alternative compatible Boolean function whose dependence on i differs from the target.

* To test whether a function can be **independent** of i, group all addresses into pairs (a, a+2^i), with a_i=0. Each pair must share one binary value. The fixed queried values enforce either 0, 1, or leave the pair free. Writing z_w for the number of 1-valued pairs with |a|=w, the layer constraints are A_w=z_(w-1)+z_w, z_(-1)=z_k=0. The recurrence uniquely fixes z_w; feasibility is tested against forced-one and free-pair bounds in each w group.
* To test whether a function can be **dependent** on i, there must exist at least one i-pair with unequal entries. For any candidate unequal assignment to that pair, test feasibility of independently completing the two Hamming layers to the exact prescribed totals A, respecting Q; all other layers are feasible because the observed target agrees with Q and A.

No MILP solve is used in the 147-job reproduction. Identical seeded eight-pass greedy removal is used only to replicate reported *found* certificate sizes; no claim of minimum-cardinality optimality follows.

## Reproduction

Run `python verify_k6_independent.py` inside the included `repro/` directory. Bundled input data and parsing code are in `repro/baseline/`; SciPy is optional for MILP cross-checks (otherwise exact non-MILP reproduction still runs). Input: bundled Boolean-network cnet/txt files; baseline source routines used only to parse and construct sector profiles, not to decide certificates. Output: `certificates_capped_independent.csv`, `summary.csv`, `differences.txt`.

## Status interpretation

**Issue 11 CLOSED within the previously stated 147-job capped-certificate blocker.** Does not imply every experiment in the manuscript is newly reproduced. **Issue 14 remains scoped to boundary formula/reporting**, and larger historical adaptive-search runs for (6,2)–(8,2) remain not independently reproduced. No overall count inflation: under existing scoped ledger accounting, 13 CLOSED / 2 PARTIAL / 3 OPEN.
