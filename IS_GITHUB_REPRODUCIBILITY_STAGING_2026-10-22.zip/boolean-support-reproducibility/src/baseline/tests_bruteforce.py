"""Exhaustive check of Theorem 1 (E_k formula) against truth-table enumeration for m <= 4."""
import sys
from collections import defaultdict
from dgsupport import profile_of, support_of, spectrum, total_functions, all_profiles

def run(m):
    counts = defaultdict(lambda: defaultdict(int))
    for tt in range(1 << (1 << m)):
        counts[profile_of(tt, m)][len(support_of(tt, m))] += 1
    bad = 0
    nprof = 0
    for A in all_profiles(m):
        nprof += 1
        sp = spectrum(A)
        got = dict(counts.get(A, {}))
        if sp != got:
            bad += 1
            print("MISMATCH", m, A, sp, got)
        assert sum(sp.values()) == total_functions(A)
    print(f"m={m}: profiles={nprof}, functions={1 << (1 << m)}, mismatches={bad}")
    return bad

if __name__ == "__main__":
    tot = sum(run(m) for m in (1, 2, 3, 4))
    sys.exit(1 if tot else 0)
