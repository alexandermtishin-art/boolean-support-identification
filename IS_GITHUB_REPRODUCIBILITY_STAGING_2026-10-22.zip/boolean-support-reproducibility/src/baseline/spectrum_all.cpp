// Exact enumeration over ALL sector profiles for given m using the Theorem-1 formulas (128-bit integers).
// Prints: number of profiles, ambiguous profiles, functions in ambiguous profiles, support-width histogram, gap profiles.
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <map>
typedef __int128 i128;
static long Cn[16][16];
static i128 binom_big(long n,long k){ // C(n,k) for n up to 20, result fits 128
  if(k<0||k>n) return 0; i128 r=1; for(long i=1;i<=k;i++){ r=r*(n-k+i)/i;} return r;}
static bool divide(std::vector<long>&A){ // divide by (1+t) in place; false if not divisible
  int n=A.size()-1; if(n==0) return false;
  std::vector<long> q(n); std::vector<long> rem=A;
  for(int j=n;j>=1;j--){ q[j-1]=rem[j]; rem[j-1]-=q[j-1]; rem[j]=0;}
  if(rem[0]!=0) return false; A=q; return true;}
static i128 Wr(const std::vector<long>&A,int r){
  int m=A.size()-1,k=m-r; std::vector<long> B=A;
  for(int i=0;i<r;i++) if(!divide(B)) return 0;
  i128 w=1; for(int j=0;j<=k;j++){ if(B[j]<0||B[j]>Cn[k][j]) return 0; w*=binom_big(Cn[k][j],B[j]); }
  return w;}
static i128 Fall(const std::vector<long>&A){
  int m=A.size()-1; i128 s=0;
  for(int r=0;r<=m;r++){ i128 w=Wr(A,r); if(!w) continue; s+=((r&1)?-1:1)*(i128)Cn[m][r]*w;} return s;}
static i128 Ek(const std::vector<long>&A,int k){
  int m=A.size()-1; std::vector<long> B=A;
  for(int i=0;i<m-k;i++) if(!divide(B)) return 0;
  for(int j=0;j<=k;j++) if(B[j]<0||B[j]>Cn[k][j]) return 0;
  return (i128)Cn[m][k]*Fall(B);}
static void pr(i128 x){ char b[64]; int n=0; if(x==0){puts("0");return;} while(x>0){b[n++]='0'+(int)(x%10);x/=10;} while(n--)putchar(b[n]); }
int main(int argc,char**argv){
  int m=atoi(argv[1]);
  for(int n=0;n<16;n++){Cn[n][0]=1;for(int k=1;k<=n;k++)Cn[n][k]=Cn[n-1][k-1]+(k<=n-1?Cn[n-1][k]:0);}
  std::vector<long> rad(m+1); for(int j=0;j<=m;j++) rad[j]=Cn[m][j]+1;
  std::vector<long> A(m+1,0);
  long nprof=0,namb=0,ngap=0; i128 nf=0,nfamb=0; std::map<int,long> width; std::map<int,i128> widthf;
  while(true){
    nprof++;
    i128 tot=1; for(int j=0;j<=m;j++) tot*=binom_big(Cn[m][j],A[j]);
    int kmin=-1,kmax=-1,cnt=0; i128 chk=0;
    for(int k=0;k<=m;k++){ i128 e=Ek(A,k); if(e>0){ if(kmin<0)kmin=k; kmax=k; cnt++; chk+=e; } }
    if(chk!=tot){ printf("ERROR profile mismatch\n"); return 1; }
    nf+=tot;
    if(cnt>1){ namb++; nfamb+=tot; width[kmax-kmin]++; widthf[kmax-kmin]+=tot; if(cnt!=kmax-kmin+1) ngap++; }
    int j=m; while(j>=0){ if(++A[j]<rad[j]) break; A[j]=0; j--; }
    if(j<0) break;
  }
  printf("m=%d profiles=%ld ambiguous=%ld (%.4f%%) profiles_with_gaps_in_spectrum=%ld\n",m,nprof,namb,100.0*namb/nprof,ngap);
  printf("functions total="); pr(nf); printf(" in_ambiguous="); pr(nfamb); printf(" fraction=%.6f\n",(double)nfamb/(double)nf);
  for(auto&kv:width){ printf("width %d: profiles=%ld functions=",kv.first,kv.second); pr(widthf[kv.first]); puts(""); }
  return 0;}
