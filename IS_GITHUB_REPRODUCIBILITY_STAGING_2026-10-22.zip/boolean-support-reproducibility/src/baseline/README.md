# Boolean support identification — public reproducibility package

This archive contains public code, data and computed results for *Exact Support Identification of Boolean Guards from Sector Counts and Weight-Limited Queries*.

## Contents
- `dgsupport/` exact sector-profile support spectrum implementation
- `data/` published Boolean network model inputs; see `data/LICENSE_cana_MIT.txt`
- `results/` generated result tables and figures
- root Python/C/C++ source files and `run_all.sh`
- `certificates/` independent exhaustive verifier of the 16-query lower bound

## Reproduction
Requirements: Python 3 with numpy, scipy and matplotlib; GCC/G++; OpenMP for `enum5.c`.
Run `bash run_all.sh` for the full pipeline; this may require substantial compute and memory.
Compile the independent adaptive-search verifier via `g++ -O3 -std=c++17 certificates/independent_16_fast.cpp -o independent_16_fast` and run `./independent_16_fast`. The supplied log reports an author-side completed execution; any independent reproduction must run the program locally.

The 81 Boolean network *files* are not necessarily independent biological systems. Instance-specific certificates are not minimax query complexities. Sector counts are assumed known in the addressed-query model; their measurement cost is not included. The Hamming-weight cap is combinatorial, not a physical energy measurement.

No unpublished drafts, reviewer correspondence, internal research history, or secrets are part of this archive.
