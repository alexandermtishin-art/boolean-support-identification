"""Checks for the collision propositions, the proof inequality of Appendix C and the noise numbers of Appendix D."""
import itertools
from math import comb, log, ceil
from dgsupport import profile_of, support_of

def tt_from(fun, m):
    return sum(1 << y for y in range(1 << m) if fun(tuple((y >> i) & 1 for i in range(m))))

# Proposition 1: monotone pair, m=4 (spectator y4 for f)
f = lambda y: int(y[0] + y[1] + y[2] >= 2)
g = lambda y: int((y[0] and (y[1] or y[2] or y[3])) or (y[1] and y[2] and y[3]))
tf, tg = tt_from(f, 4), tt_from(g, 4)
assert profile_of(tf, 4) == profile_of(tg, 4) == (0, 0, 3, 4, 1)
assert len(support_of(tf, 4)) == 3 and len(support_of(tg, 4)) == 4
diff = [sum(y) for y in itertools.product((0, 1), repeat=4) if f(y) != g(y)]
print("Prop 1: profile", profile_of(tf, 4), "supports", len(support_of(tf, 4)), len(support_of(tg, 4)), "min differing weight", min(diff))
# Proposition 2: parametric family
F = {(0, 0, 0), (0, 0, 1), (0,1, 1), (1, 1, 1)}
for m in range(3, 8):
    def fm(y, m=m):
        u = y[:3]; p = sum(y[3:]) % 2
        if p: u = (u[2], u[1], u[0])
        return int(u in F)
    gm = lambda y: int(y[0] == y[1])
    if m <= 6:
        a, b = tt_from(fm, m), tt_from(gm, m)
        assert profile_of(a, m) == profile_of(b, m)
        sa, sb = len(support_of(a, m)), len(support_of(b, m))
        low = min(sum(y) for y in itertools.product((0, 1), repeat=m) if fm(y) != gm(y))
        print(f"Prop 2: m={m}: supports {sa} vs {sb}, equal profiles, min differing weight {low}")
        assert sa == m and sb == 2 and low == 2
# Theorem 2 proof inequality a >= b + p for m >= 2j+1, j >= 2
bad = 0
for j in range(2, 30):
    for m in range(2 * j + 1, 120):
        a, b, p = comb(m - 1, j), comb(m - 1, j - 1), -(-(m - 1) // j)
        if a < b + p: bad += 1
print("a >= b + p violations for 2<=j<30, 2j+1<=m<120:", bad)
# Appendix D noise numbers
def tail(n, eta): return sum(comb(n, i) * eta ** i * (1 - eta) ** (n - i) for i in range((n + 1) // 2, n + 1))
for L, label in ((56, "q=3"), (14, "q=4"), (1, "q=8")):
    n = 1
    while L * tail(n, 0.1) > 0.01: n += 2
    print(f"{label}: L={L}, smallest odd n={n}, readings={L*n}")
eta, delta, M, qq, d = 0.1, 0.01, 56, 4, 3
D = (1 - 2 * eta) * log((1 - eta) / eta); kap = (1 - 2 * delta) * log((1 - delta) / delta)
print("information lower bound (q=4):", round(M * kap / (D * comb(qq, d)), 2))
