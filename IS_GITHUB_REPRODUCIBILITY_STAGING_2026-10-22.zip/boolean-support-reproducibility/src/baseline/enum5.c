// Exhaustive enumeration of all 2^32 Boolean functions on m=5 variables.
// Output: for each sector profile (mixed radix) and each essential-support size, the number of functions.
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>
#define M 5
int main(void){
  uint32_t wmask[M+1]; memset(wmask,0,sizeof wmask);
  for(int y=0;y<32;y++) wmask[__builtin_popcount(y)] |= 1u<<y;
  uint32_t lo[M]; // positions with bit i == 0
  for(int i=0;i<M;i++){lo[i]=0;for(int y=0;y<32;y++) if(!((y>>i)&1)) lo[i]|=1u<<y;}
  int binom[M+1]; for(int j=0;j<=M;j++){int c=1;for(int k=0;k<j;k++)c=c*(M-k)/(k+1);binom[j]=c;}
  int radix[M+1]; long nprof=1; for(int j=0;j<=M;j++){radix[j]=binom[j]+1;nprof*=radix[j];}
  uint64_t *cnt = calloc(nprof*(M+1),sizeof(uint64_t));
  int T=omp_get_max_threads();
  uint64_t **loc = malloc(T*sizeof(uint64_t*));
  for(int t=0;t<T;t++) loc[t]=calloc(nprof*(M+1),sizeof(uint64_t));
  #pragma omp parallel
  {
    int t=omp_get_thread_num();
    uint64_t *c=loc[t];
    #pragma omp for schedule(static)
    for(int64_t x=0;x<(1LL<<32);x++){
      uint32_t tt=(uint32_t)x;
      long idx=0;
      for(int j=0;j<=M;j++) idx=idx*radix[j]+__builtin_popcount(tt&wmask[j]);
      int s=0;
      for(int i=0;i<M;i++){
        int sh=1<<i;
        uint32_t sw=((tt&lo[i])<<sh)|((tt>>sh)&lo[i]);
        if(sw!=tt) s++;
      }
      c[idx*(M+1)+s]++;
    }
  }
  for(int t=0;t<T;t++) for(long i=0;i<nprof*(M+1);i++) cnt[i]+=loc[t][i];
  FILE *f=fopen("enum5_counts.tsv","w");
  for(long idx=0;idx<nprof;idx++){
    long r=idx; int A[M+1];
    for(int j=M;j>=0;j--){A[j]=r%radix[j];r/=radix[j];}
    for(int s=0;s<=M;s++) if(cnt[idx*(M+1)+s]){
      for(int j=0;j<=M;j++) fprintf(f,"%d,",A[j]);
      fprintf(f,"\t%d\t%llu\n",s,(unsigned long long)cnt[idx*(M+1)+s]);
    }
  }
  fclose(f); return 0;}
