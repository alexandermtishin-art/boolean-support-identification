"""Certificate size of the support of real update functions, with and without knowledge of the sector profile.
A set Q of addresses is a certificate for f (given profile A, or with no profile knowledge) if every guard g that agrees
with f on Q (and has profile A when A is known) has the same support as f. Inclusion-minimal certificates are found by
greedy removal over random orders; the reported size is an upper bound on the minimum certificate size.
"""
import sys, glob, os, csv, random
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix
from multiprocessing import Pool
from exp_real_networks import parse, analyse

def support_of(k, tt):
    S = []
    for t in range(k):
        bit = 1 << t
        if any(((tt >> y) & 1) != ((tt >> (y | bit)) & 1) for y in range(1 << k) if not y & bit):
            S.append(t)
    return S

def exists_g(k, tt, Q, profile, mode, i):
    """mode 'inessential': is there g (agreeing on Q, with profile if given) not depending on variable i?
       mode 'essential': is there g depending on variable i?"""
    n = 1 << k
    pairs = [(y, y | (1 << i)) for y in range(n) if not y & (1 << i)]
    npair = len(pairs)
    nv = n + (npair if mode == 'essential' else 0)
    rows = []; lo = []; hi = []
    A = lil_matrix((n + 2 * npair + 2 + k + 2 + n, nv)); r = 0
    for y in Q:
        A[r, y] = 1; v = (tt >> y) & 1; lo.append(v); hi.append(v); r += 1
    if profile is not None:
        for w in range(k + 1):
            for y in range(n):
                if bin(y).count('1') == w:
                    A[r, y] = 1
            lo.append(profile[w]); hi.append(profile[w]); r += 1
    if mode == 'inessential':
        for a, b in pairs:
            A[r, a] = 1; A[r, b] = -1; lo.append(0); hi.append(0); r += 1
    else:
        for p, (a, b) in enumerate(pairs):
            d = n + p
            A[r, d] = 1; A[r, a] = -1; A[r, b] = -1; lo.append(-np.inf); hi.append(0); r += 1      # d <= x_a + x_b
            A[r, d] = 1; A[r, a] = 1; A[r, b] = 1; lo.append(-np.inf); hi.append(2); r += 1        # d <= 2 - x_a - x_b
        for p in range(npair):
            A[r, n + p] = 1
        lo.append(1); hi.append(np.inf); r += 1
    A = A[:r].tocsr()
    res = milp(c=np.zeros(nv), constraints=LinearConstraint(A, lo, hi), integrality=np.ones(nv),
               bounds=Bounds(0, 1), options={"presolve": True})
    return res.status == 0

def is_certificate(k, tt, S, Q, profile):
    for i in range(k):
        if exists_g(k, tt, Q, profile, 'inessential' if i in S else 'essential', i):
            return False
    return True

def minimal_cert(k, tt, profile, rng, passes=int(os.environ.get("PASSES", "8"))):
    S = set(support_of(k, tt)); n = 1 << k
    best = None
    for _ in range(passes):
        Q = list(range(n)); order = list(range(n)); rng.shuffle(order)
        for y in order:
            Q2 = [z for z in Q if z != y]
            if is_certificate(k, tt, S, Q2, profile):
                Q = Q2
        if best is None or len(Q) < best:
            best = len(Q)
    return best

def job(args):
    k, tt, A = args
    rng = random.Random(k * 1000003 + tt % 1000003)
    return (k, tt, minimal_cert(k, tt, A, rng), minimal_cert(k, tt, None, rng))

if __name__ == "__main__":
    kmax = int(sys.argv[1]) if len(sys.argv) > 1 else 6
    files = sorted(glob.glob("data/classic/*.cnet")) + sorted(glob.glob("data/cell_collective/*.txt"))
    seen = {}
    for f in files:
        for idx, k, tt in parse(f):
            if 3 <= k <= kmax:
                seen[(k, tt)] = analyse(k, tt)
    jobs = []
    meta = {}
    for (k, tt), (A, s, sp) in seen.items():
        jobs.append((k, tt, A)); meta[(k, tt)] = (A, s, len(sp) > 1)
    print("distinct tables", len(jobs), flush=True)
    with Pool(os.cpu_count()) as p:
        res = p.map(job, jobs, chunksize=1)
    with open("certificates.csv", "w", newline="") as fh:
        w = csv.writer(fh); w.writerow(["k", "truth_table", "profile", "support_size", "ambiguous", "cert_with_profile", "cert_no_profile", "addresses"])
        for k, tt, cp, cn in sorted(res):
            A, s, amb = meta[(k, tt)]
            w.writerow([k, tt, " ".join(map(str, A)), s, int(amb), cp, cn, 1 << k])
