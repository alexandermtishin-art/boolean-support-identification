// Exact minimax (game-tree search) for support identification in the threshold-profile class of Theorem 2.
// Hypothesis class: Boolean functions on m controls with sector counts A_w=0 (w<j), A_j=C(m-1,j), A_w=C(m,w) (w>j).
// Only weight-j addresses are informative. State = partial assignment (ones, zeros) over the P=C(m,j) addresses.
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <vector>
#include <unordered_map>
#include <algorithm>
typedef unsigned long long u64;
int m,j,P,a,b; std::vector<u64> avoid; // avoid[i]: addresses not containing i (ones of f_i)
static u64 Cb[64][64];
struct Key{u64 o,z; bool operator==(const Key&x)const{return o==x.o&&z==x.z;}};
struct H{size_t operator()(const Key&k)const{return k.o*0x9E3779B97F4A7C15ULL ^ (k.z+0x7F4A7C15ULL)*0xC2B2AE3D27D4EB4FULL;}};
struct Val{int fail=-1,succ=1000;}; // fail: largest budget known insufficient; succ: smallest budget known sufficient
std::unordered_map<Key,Val,H> memo;
static bool terminal(u64 o,u64 z){
  int q=__builtin_popcountll(o|z); int r=P-q; int c=a-__builtin_popcountll(o); if(c<0||c>r) return true; // inconsistent (never reached)
  int s=0; for(int i=0;i<m;i++) if((o&~avoid[i])==0 && (z&avoid[i])==0) s++;
  if(s==0) return true; return Cb[r][c]==1;}
static bool solve(u64 o,u64 z,int budget){
  if(terminal(o,z)) return true; if(budget==0) return false;
  Key k{o,z}; auto it=memo.find(k); if(it!=memo.end()){ if(budget<=it->second.fail) return false; if(budget>=it->second.succ) return true; }
  int r=P-__builtin_popcountll(o|z), c=a-__builtin_popcountll(o);
  bool ok=false;
  if(c>=1 && c<=r-1){
    for(int p=0;p<P && !ok;p++){ u64 bit=1ULL<<p; if((o|z)&bit) continue;
      if(solve(o|bit,z,budget-1) && solve(o,z|bit,budget-1)) ok=true; }
  }
  Val &v=memo[k]; if(ok) v.succ=std::min(v.succ,budget); else v.fail=std::max(v.fail,budget);
  return ok;}
int main(int argc,char**argv){
  m=atoi(argv[1]); j=atoi(argv[2]);
  for(int n=0;n<64;n++){Cb[n][0]=1;for(int k=1;k<=n;k++)Cb[n][k]=Cb[n-1][k-1]+(k<=n-1?Cb[n-1][k]:0);}
  std::vector<int> pts; for(int x=0;x<(1<<m);x++) if(__builtin_popcount(x)==j) pts.push_back(x);
  P=pts.size(); a=Cb[m-1][j]; b=Cb[m-1][j-1]; if(P>63){puts("too many addresses");return 1;}
  avoid.assign(m,0); for(int i=0;i<m;i++) for(int p=0;p<P;p++) if(!((pts[p]>>i)&1)) avoid[i]|=1ULL<<p;
  int T=b+(m-1+j-1)/j; // claimed value
  // root: by symmetry (transitive action on addresses) the first query may be fixed to address 0
  auto solveRoot=[&](int budget){ u64 bit=1ULL; return solve(bit,0,budget-1)&&solve(0,bit,budget-1); };
  bool upper=solveRoot(T), lower=solveRoot(T-1);
  printf("m=%d j=%d addresses=%d a=%d b=%d claimed T=%d : solvable_with_T=%s solvable_with_T-1=%s -> minimax %s T (states=%zu)\n",
    m,j,P,a,b,T,upper?"yes":"no",lower?"yes":"no",(upper&&!lower)?"==":"!=",memo.size());
  return 0;}
