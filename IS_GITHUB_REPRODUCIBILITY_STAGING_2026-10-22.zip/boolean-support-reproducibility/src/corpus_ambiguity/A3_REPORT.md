# A3 — Ambiguity of support size vs labelled support

Source: `boolean-support-identification_PUBLIC_AUDITED.zip`, bundled 81-model CANA-derived network corpus; original `exp_real_networks.py` parser. Independently recount all truth tables from source model files. Restrict to 3–14 inputs. Unique table identity is `(k, truth_table_integer)`; CSV writes the integer in hexadecimal to avoid numeric conversion limits for large truth tables.

| Unit of analysis | N | Cardinality ambiguity | Labelled-support ambiguity | Label-only additional cases |
|---|---:|---:|---:|---:|
| Node-function occurrences | 1,125 | 71 | 77 | 6 |
| Distinct truth tables | 508 | 63 | 68 | 5 |

The five newly flagged unique truth tables (the six node occurrences collapse to five distinct truth tables) have a unique proper support cardinality, but admit several labelled supports under permutation of control coordinates.

## Criterion
A profile is ambiguous in support cardinality if its support-size spectrum contains at least two values. It is ambiguous in labelled support if it admits two distinct sets of essential coordinate labels. Permutation invariance means a single admissible proper nonempty support automatically produces multiple labelled supports; the exact number of possible labelled supports is `sum(comb(m,k) for k in admissible support sizes)`.

These results describe *profile-conditioned feasible functions*, not differences between observed ground-truth supports in the corpus.

## Reproduction
`python audit_unique.py boolean-support-identification_PUBLIC_AUDITED.zip output_directory`

The script independently parses all bundled model source files, reconstructs Boolean truth tables, computes support-size spectra using the repository module, and asserts the 1125/71/77 and 508/63/68 counts.

A3 closes only the two-denominator definitional and counting discrepancy. It does not prove the adequacy of the empirical motivation, reviewer satisfaction, or the journal fit.
