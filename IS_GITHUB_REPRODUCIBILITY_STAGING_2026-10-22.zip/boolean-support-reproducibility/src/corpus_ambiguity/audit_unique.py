"""Reproduce support-cardinality vs labelled-support ambiguity from public archive.
Place this script alongside the extracted exp_real_networks.py, dgsupport and data,
or give the public archive as first argument. No external dependencies.
"""
import csv, glob, json, os, sys, zipfile, tempfile, collections
from pathlib import Path

def calculate(base):
    sys.path.insert(0,str(base))
    from exp_real_networks import parse, analyse
    occ=[]; uniq={}
    for path in sorted((base/'data/classic').glob('*.cnet')) + sorted((base/'data/cell_collective').glob('*.txt')):
        for idx,k,tt in parse(str(path)):
            if not 3<=k<=14: continue
            A,s,sp=analyse(k,tt)
            possible=set(sp.keys())
            card=len(possible)>1
            labelled=card or any(0<p<k for p in possible)
            record=dict(k=k,truth_table=hex(tt),profile=' '.join(map(str,A)),support_size=s,possible_sizes=' '.join(map(str,sorted(possible))),cardinality_ambiguous=int(card),labelled_ambiguous=int(labelled),model=path.name,node=idx)
            occ.append(record);uniq[(k,tt)]=record
    return occ,list(uniq.values())

def summary(rows):
    return dict(total=len(rows),cardinality_ambiguous=sum(x['cardinality_ambiguous'] for x in rows),labelled_ambiguous=sum(x['labelled_ambiguous'] for x in rows),labelled_only=sum(x['labelled_ambiguous'] and not x['cardinality_ambiguous'] for x in rows),by_k=[dict(k=k,total=sum(x['k']==k for x in rows),cardinality=sum(x['k']==k and x['cardinality_ambiguous'] for x in rows),labelled=sum(x['k']==k and x['labelled_ambiguous'] for x in rows)) for k in sorted({x['k'] for x in rows})])

def main():
    archive=Path(sys.argv[1] if len(sys.argv)>1 else '/mnt/data/boolean-support-identification_PUBLIC_AUDITED.zip')
    output=Path(sys.argv[2] if len(sys.argv)>2 else Path(__file__).parent)
    output.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp)
        with zipfile.ZipFile(archive) as z:
            required=[n for n in z.namelist() if n.startswith('data/') or n.startswith('dgsupport/') or n=='exp_real_networks.py']
            z.extractall(root,required)
        occ,uni=calculate(root)
    report={'method':'deduplicate by (k, truth_table); m>=3','occurrences':summary(occ),'unique_tables':summary(uni)}
    assert (report['occurrences']['total'],report['occurrences']['cardinality_ambiguous'],report['occurrences']['labelled_ambiguous'])==(1125,71,77)
    assert (report['unique_tables']['total'],report['unique_tables']['cardinality_ambiguous'],report['unique_tables']['labelled_ambiguous'])==(508,63,68)
    (output/'A3_counts.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
    with (output/'A3_unique_tables.csv').open('w',newline='') as fp:
        fields=['k','truth_table','profile','support_size','possible_sizes','cardinality_ambiguous','labelled_ambiguous','model','node']
        writer=csv.DictWriter(fp,fieldnames=fields);writer.writeheader();writer.writerows(sorted(uni,key=lambda x:(x['k'],x['truth_table'])))
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
