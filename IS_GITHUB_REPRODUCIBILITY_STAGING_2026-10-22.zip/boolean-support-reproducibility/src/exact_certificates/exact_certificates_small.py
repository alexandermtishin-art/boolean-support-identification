#!/usr/bin/env python3
"""Exact minimum labelled-support certificate by exhaustive address-set enumeration.
For each known target truth table f with sector profile A, enumerate all g with A.
Q certifies supp(f) iff every g with supp(g)!=supp(f) differs on at least one x in Q.
"""
import csv,io,itertools,zipfile,collections,math,sys,json,time

def support(k,t):
 s=0
 for i in range(k):
  if any(((t>>x)&1)!=((t>>(x|(1<<i)))&1) for x in range(1<<k) if not x>>i&1):s|=1<<i
 return s

def profiles(k):
 return [[x for x in range(1<<k) if x.bit_count()==j] for j in range(k+1)]

def all_functions(k,A):
 layers=profiles(k)
 for sets in itertools.product(*(itertools.combinations(layer,a) for layer,a in zip(layers,A))):
  x=0
  for subset in sets:
   for q in subset:x|=1<<q
  yield x

def exact_cert(k,target,funcs,supps):
 wrong=[];target_s=support(k,target)
 for g,s in zip(funcs,supps):
  if s==target_s:continue
  diff=target^g
  if diff==0:raise AssertionError('support mismatch')
  wrong.append(diff)
 if not wrong:return 0,0
 # dominance: if diff1 is subset of diff2, then only diff1 constraint is needed.
 wrong=sorted(set(wrong),key=lambda x:(x.bit_count(),x))
 minimal=[]
 for m in wrong:
  if not any(m&v==v for v in minimal):minimal.append(m)
 N=1<<k
 for size in range(N+1):
  for combo in itertools.combinations(range(N),size):
   q=sum(1<<x for x in combo)
   if all(q & m for m in minimal):return size,q
 raise AssertionError('unreachable')

def main():
 zip_path=sys.argv[1] if len(sys.argv)>1 else '/mnt/data/boolean-support-identification_PUBLIC_AUDITED.zip'
 with zipfile.ZipFile(zip_path) as z:
  data=list(csv.DictReader(io.StringIO(z.read('results/certificates.csv').decode())))
 out=[];summ=[]
 for k in [3,4]:
  d=[r for r in data if int(r['k'])==k and r['ambiguous']=='1']
  for a,group in itertools.groupby(sorted(d,key=lambda r:r['profile']),key=lambda r:r['profile']):
   rows=list(group);A=tuple(map(int,a.split()))
   funcs=list(all_functions(k,A)); supps=[support(k,g) for g in funcs]
   unique_supports=len(set(supps))
   for r in rows:
    t=int(r['truth_table']); start=time.monotonic()
    exact,witness=exact_cert(k,t,funcs,supps)
    heuristic=int(r['cert_with_profile'])
    assert exact<=heuristic,(k,A,t,exact,heuristic)
    out.append(dict(k=k,truth_table=t,profile=a,profile_class=len(funcs),support_classes=unique_supports,exact_min_certificate=exact,original_upper_bound=heuristic,gap=heuristic-exact,certificate_addresses=' '.join(map(str,[i for i in range(1<<k) if witness>>i&1])),runtime_sec=round(time.monotonic()-start,5)))
   print('completed',k,A,'class',len(funcs),'n',len(rows),flush=True)
 outdir='/mnt/data/DG_IS_CERTIFICATE_EXACT_R6'
 with open(outdir+'/exact_certificates_k3_k4.csv','w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=out[0].keys());w.writeheader();w.writerows(out)
 for k in [3,4]:
  a=[r for r in out if r['k']==k]
  summ.append(dict(k=k,n=len(a),exact_mean=round(sum(r['exact_min_certificate'] for r in a)/len(a),6),heuristic_mean=round(sum(r['original_upper_bound'] for r in a)/len(a),6),n_gap_positive=sum(r['gap']>0 for r in a),max_gap=max(r['gap'] for r in a)))
 print(json.dumps(summ,indent=2))
 with open(outdir+'/summary.json','w') as f:json.dump({'summary':summ,'n':len(out),'rows':out},f,indent=2)
if __name__=='__main__':main()
