#!/usr/bin/env python3
"""Independent exhaustive reachable-states, ascending-cardinality DP for m=4 profiles."""
import itertools,json

def run(A,q):
 m=len(A)-1; layers=[[x for x in range(1<<m) if x.bit_count()==j] for j in range(m+1)]
 H=[]
 for chosen in itertools.product(*(itertools.combinations(L,k) for L,k in zip(layers,A))):
  truth={x for L in chosen for x in L}
  support=tuple(i for i in range(m) if any((x in truth)!=((x^(1<<i)) in truth) for x in range(1<<m)))
  H.append((truth,support))
 n=len(H);queries=[]
 for x in range(1<<m):
  if x.bit_count()>q:continue
  mask=sum(1<<i for i,(truth,_) in enumerate(H) if x in truth)
  if mask not in queries:queries.append(mask)
 full=(1<<n)-1;reachable={full}; stack=[full]
 while stack:
  S=stack.pop()
  for mask in queries:
   for v in (S&mask,S&~mask):
    if v and v!=S and v not in reachable:reachable.add(v);stack.append(v)
 values={}
 for S in sorted(reachable,key=int.bit_count):
  if len({H[i][1] for i in range(n) if S>>i&1})==1:values[S]=0;continue
  choices=[1+max(values[S&mask],values[S&~mask]) for mask in queries if S&mask and S&~mask]
  values[S]=min(choices) if choices else float("inf")
 return {'profile':A,'q':q,'n':n,'states':len(reachable),'minimax':values[full]}
out=[run(A,q) for A,q in itertools.product([(0,1,1,0,0),(0,0,1,1,0)],(2,3,4))]
print(json.dumps(out,indent=2))
open(str(__import__('pathlib').Path(__file__).with_name('independent_m4_results.json')),'w').write(json.dumps(out,indent=2))
