from exact_profile_minimax import hyp
from itertools import product
import json
Aset=[(0,1,1,0),(0,1,2,1),(0,2,2,0),(1,2,1,0)]
results=[]
for A,q in product(Aset,[1,2,3]):
    H=hyp(3,A); n=len(H)
    target=[s for _,s in H]
    patterns=[sum(1<<i for i,(tbl,s) in enumerate(H) if tbl>>x&1) for x in range(8) if x.bit_count()<=q]
    value=[999]*(1<<n)
    for S in range(1,1<<n):
        supports={target[i] for i in range(n) if S>>i&1}
        if len(supports)==1:value[S]=0
        else:
            value[S]=min((1+max(value[S&P],value[S&~P]) for P in patterns if S&P and S&~P),default=999)
    out={'profile':A,'q':q,'exact_cost':None if value[-1]>=999 else value[-1],'method':'independent bottom-up all-subsets DP'}
    results.append(out)
    print(out)
open(str(__import__('pathlib').Path(__file__).with_name('independent_crosscheck.json')),'w').write(json.dumps(results,indent=2))
