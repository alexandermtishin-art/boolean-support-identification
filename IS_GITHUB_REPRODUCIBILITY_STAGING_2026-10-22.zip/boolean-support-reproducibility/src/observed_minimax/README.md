# Reproduction of exact support recovery on observed profiles

Input: the audited public data archive `boolean-support-identification_PUBLIC_AUDITED.zip` containing `results/real_networks_nodes.csv`. Copy it into this directory, or set environment variable `DG_ARCHIVE` to its full path.

Run `python bridge_verified.py` to enumerate all compatible functions, compute exact smallest known-function support certificates by exhaustive address-subset search, and exact adaptive minimax costs via memoized decision-tree recursion.

Run `python independent_m4_crosscheck.py` for a separately implemented bottom-up enumeration of reachable version spaces on the two four-input profiles; run `python crosscheck_m3.py` for the three-input independent check.

The inputs are public Boolean-network rules used only to select observed sector profiles. The minimax calculations enumerate ALL truth tables with each selected profile, not just the published function. Queries have Hamming weight <= q.

Output: `bridge_results.json`, `independent_m4_results.json`, `exact_m3_results.json`, `independent_crosscheck.json`. `minimax` null (or nonfinite in the top-down intermediate output) means identification is impossible under that cap.

The two solvers are separately implemented but authored in the same research process; this is an implementation cross-check, not independent external peer verification.
