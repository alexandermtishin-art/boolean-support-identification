import os,sys,csv,random,collections,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent/'baseline';sys.path.insert(0,str(ROOT))
from exp_real_networks import parse,analyse
def support_of(k,tt):
 return [i for i in range(k) if any(((tt>>y)&1)!=((tt>>(y|(1<<i)))&1) for y in range(1<<k) if not y&(1<<i))]

def cert(k,tt,A,Q):
 n=1<<k; Q=set(Q); sup=set(support_of(k,tt)); layers=[[] for _ in range(k+1)]
 for y in range(n): layers[y.bit_count()].append(y)
 fixed=[{} for _ in range(k+1)]
 for y in Q: fixed[y.bit_count()][y]=(tt>>y)&1
 forced=[sum(x.values()) for x in fixed]; free=[len(layers[w])-len(fixed[w]) for w in range(k+1)]
 def possible(y,v):
  w=y.bit_count(); x=fixed[w]
  if y in x: return x[y]==v and forced[w]<=A[w]<=forced[w]+free[w]
  return forced[w]+v<=A[w]<=forced[w]+v+free[w]-1
 for i in range(k):
  pairs=[(a,a|(1<<i)) for a in range(n) if not a&(1<<i)]
  if i in sup:
   # alternative independent of i, pairwise matched assignments. Forced endpoints should agree
   groups=[[0,0,0] for _ in range(k)] # forced 0, forced 1, free
   valid=True
   for a,b in pairs:
    w=a.bit_count(); va=fixed[w].get(a);vb=fixed[w+1].get(b)
    if va is not None and vb is not None and va!=vb: valid=False;break
    v=va if va is not None else vb
    if v is None: groups[w][2]+=1
    else: groups[w][v]+=1
   if valid:
    zprev=0; valid2=True
    for w in range(k):
     z=A[w]-zprev
     lo=groups[w][1];hi=lo+groups[w][2]
     if not lo<=z<=hi: valid2=False;break
     zprev=z
    if valid2 and zprev==A[k]:return False
  else:
   # alternative essential: at least one different pair consistent with layer totals
   for a,b in pairs:
    if (possible(a,0) and possible(b,1)) or (possible(a,1) and possible(b,0)):
     return False
 return True

if __name__=='__main__':
 seen={}
 for f in sorted(ROOT.glob('data/classic/*.cnet'))+sorted(ROOT.glob('data/cell_collective/*.txt')):
  for idx,k,tt in parse(str(f)):
   if 3<=k<=6:seen[(k,tt)]=analyse(k,tt)
 jobs=[(k,tt,A,q) for (k,tt),(A,s,sp) in sorted(seen.items()) if len(sp)>1 for q in range(1,k)]
 print('JOBS',len(jobs),flush=True)
 # validate against published MILP on bounded random data incl variable caps
 try:
  from exp_certificates import is_certificate
 except ImportError:
  is_certificate=None
 rng=random.Random(10021)
 for k in ((3,4,5) if is_certificate else ()):
  small=[(a,t) for (kk,t),(a,s,sp) in seen.items() if kk==k]
  for _ in range(min(12,len(small)*2)):
   a,t=rng.choice(small);q={y for y in range(1<<k) if rng.random()<0.5}
   x=cert(k,t,a,q);z=is_certificate(k,t,set(support_of(k,t)),sorted(q),a)
   if x!=z:raise RuntimeError(f'MILP disagreement {k} {t} {q} {x} {z}')
 print('MILP CROSSCHECK PASS',flush=True)
 out=[];start=time.time(); passes=int(os.environ.get('PASSES','8'))
 for ix,(k,tt,A,q) in enumerate(jobs):
  pool=[y for y in range(1<<k) if y.bit_count()<=q]
  if not cert(k,tt,A,pool):out.append((k,tt,q,-1));continue
  best=None;rng=random.Random(k*7919+tt%7919+q)
  for _ in range(passes):
   Q=set(pool);order=list(pool);rng.shuffle(order)
   for y in order:
    if cert(k,tt,A,Q-{y}):Q.remove(y)
   best=len(Q) if best is None else min(best,len(Q))
  out.append((k,tt,q,best))
  if ix%30==0:print('completed',ix+1,'/',len(jobs),flush=True)
 p=Path(__file__).resolve().parent/'outputs';p.mkdir(exist_ok=True)
 with (p/'certificates_capped_independent.csv').open('w',newline='') as h:
  w=csv.writer(h);w.writerow(['k','truth_table','cap_q','cert_size_or_minus1_if_none']);w.writerows(out)
 summary=[]
 for (k,q),vals in sorted(((k,q),[v for kk,tt,qq,v in out if kk==k and qq==q]) for k,q in {(k,q) for k,tt,q,v in out}):
  ok=[v for v in vals if v>=0];summary.append((k,q,len(vals),len(ok),round(sum(ok)/len(ok),2) if ok else None))
 print('SUMMARY',summary,'SECONDS',time.time()-start,flush=True)
 with (p/'summary.csv').open('w',newline='') as h:
  w=csv.writer(h);w.writerow(['k','q','ambiguous','provable','mean_size']);w.writerows(summary)
 existing={}
 with (ROOT/'results/certificates_capped.csv').open() as h:
  for r in csv.DictReader(h):existing[(int(r['k']),int(r['truth_table']),int(r['cap_q']))]=int(r['cert_size_or_minus1_if_none'])
 mism=[(x,existing.get(x[:3])) for x in out if existing.get(x[:3])!=x[3]]
 print('ARCHIVE_DIFFERENCES',len(mism),mism[:20],flush=True)
 with (p/'differences.txt').open('w') as h:h.write(repr(mism))
