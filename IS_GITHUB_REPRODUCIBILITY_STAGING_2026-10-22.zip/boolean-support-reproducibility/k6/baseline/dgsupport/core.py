"""Core routines: sector profiles, essential supports, exact support spectrum (Theorem 1)."""
from math import comb
from functools import lru_cache
from itertools import product


def profile_of(tt, m):
    """Sector-count profile (A_0..A_m) of a truth table given as an integer bitmask over y in [0,2^m)."""
    A = [0] * (m + 1)
    for y in range(1 << m):
        if (tt >> y) & 1:
            A[bin(y).count("1")] += 1
    return tuple(A)


def support_of(tt, m):
    """Set of essential variables of a truth table."""
    S = []
    for i in range(m):
        bit = 1 << i
        for y in range(1 << m):
            if not y & bit and ((tt >> y) & 1) != ((tt >> (y | bit)) & 1):
                S.append(i)
                break
    return tuple(S)


def divide_one_plus_t(A):
    """Exact division of polynomial A (coefficient list, low to high) by (1+t); None if not divisible."""
    n = len(A) - 1
    if n == 0:
        return None if A[0] != 0 else [0]
    q = [0] * n
    rem = list(A)
    for j in range(n, 0, -1):
        q[j - 1] = rem[j]
        rem[j - 1] -= q[j - 1]
        rem[j] = 0
    return q if rem[0] == 0 else None


def divide_r(A, r):
    B = list(A)
    for _ in range(r):
        B = divide_one_plus_t(B)
        if B is None:
            return None
    return B


def W(A, r):
    """W_r(A): number of functions on k=m-r variables with profile A/(1+t)^r (0 if inadmissible)."""
    m = len(A) - 1
    k = m - r
    if k < 0:
        return 0
    B = divide_r(A, r)
    if B is None:
        return 0
    w = 1
    for j in range(k + 1):
        if B[j] < 0 or B[j] > comb(k, j):
            return 0
        w *= comb(comb(k, j), B[j])
    return w


def F_all_essential(A):
    """Number of Boolean functions on m variables with profile A and all m variables essential."""
    m = len(A) - 1
    return sum((-1) ** r * comb(m, r) * W(A, r) for r in range(m + 1))


def E_k(A, k):
    """Number of functions with profile A whose essential support has exactly k variables."""
    m = len(A) - 1
    B = divide_r(A, m - k)
    if B is None:
        return 0
    for j in range(k + 1):
        if B[j] < 0 or B[j] > comb(k, j):
            return 0
    return comb(m, k) * F_all_essential(B)


def spectrum(A):
    """{k: E_k(A)} for k with E_k>0."""
    m = len(A) - 1
    out = {}
    for k in range(m + 1):
        e = E_k(A, k)
        if e > 0:
            out[k] = e
    return out


def total_functions(A):
    t = 1
    m = len(A) - 1
    for j in range(m + 1):
        t *= comb(comb(m, j), A[j])
    return t


def all_profiles(m):
    ranges = [range(comb(m, j) + 1) for j in range(m + 1)]
    return product(*ranges)
