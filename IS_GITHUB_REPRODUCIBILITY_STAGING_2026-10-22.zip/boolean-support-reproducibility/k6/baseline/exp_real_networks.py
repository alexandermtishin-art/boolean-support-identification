"""Prevalence of sector-profile ambiguity in update functions of published Boolean regulatory networks.
Models: bundled cnet files of the CANA distribution (MIT licence); see data/LICENSE_cana_MIT.txt.
"""
import glob, os, sys, csv, itertools
from dgsupport import spectrum

def expand(pattern):
    pos = [i for i, c in enumerate(pattern) if c == "-"]
    for bits in itertools.product("01", repeat=len(pos)):
        p = list(pattern)
        for i, b in zip(pos, bits):
            p[i] = b
        yield "".join(p)

def parse(path):
    """Return list of (node_index, k, truth_table_int) for nodes with k>=1 inputs."""
    nodes = []
    lines = open(path, encoding="utf-8", errors="ignore").read().split("\n")
    i = 0
    while i < len(lines):
        ln = lines[i].strip()
        if ln.startswith(".n"):
            parts = ln.split()
            idx, k = int(parts[1]), int(parts[2])
            i += 1
            rows = []
            while i < len(lines) and lines[i].strip() and not lines[i].startswith("#") and not lines[i].startswith("."):
                rows.append(lines[i].strip()); i += 1
            if k >= 1:
                tt = 0
                for r in rows:
                    f = r.split()
                    if len(f) != 2 or len(f[0]) != k:
                        continue
                    if f[1] != "1":
                        continue
                    for pat in expand(f[0]):
                        y = sum(1 << t for t, c in enumerate(pat) if c == "1")
                        tt |= 1 << y
                nodes.append((idx, k, tt))
            continue
        i += 1
    return nodes

def analyse(k, tt):
    A = [0] * (k + 1)
    for y in range(1 << k):
        if (tt >> y) & 1:
            A[bin(y).count("1")] += 1
    s = 0
    for t in range(k):
        bit = 1 << t
        if any(((tt >> y) & 1) != ((tt >> (y | bit)) & 1) for y in range(1 << k) if not y & bit):
            s += 1
    sp = spectrum(tuple(A))
    return tuple(A), s, sp

if __name__ == "__main__":
    files = sorted(glob.glob("data/classic/*.cnet")) + sorted(glob.glob("data/cell_collective/*.txt"))
    rows = []
    for f in files:
        try:
            nodes = parse(f)
        except Exception as e:
            print("skip", f, e); continue
        for idx, k, tt in nodes:
            if k > 14:
                continue
            A, s, sp = analyse(k, tt)
            assert s in sp, (f, idx, A, s, sp)          # consistency: true support lies in the spectrum
            rows.append(dict(model=os.path.basename(f), node=idx, k=k, essential=s, profile=" ".join(map(str, A)),
                             kmin=min(sp), kmax=max(sp), nsizes=len(sp), functions=sum(sp.values())))
    with open("real_networks_nodes.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    models = sorted({r["model"] for r in rows})
    print("models", len(models), "nodes", len(rows))
    for lo, hi in [(1, 2), (3, 4), (5, 6), (7, 14), (3, 14)]:
        sub = [r for r in rows if lo <= r["k"] <= hi]
        amb = [r for r in sub if r["nsizes"] > 1]
        print(f"k in [{lo},{hi}]: nodes={len(sub)} ambiguous={len(amb)} ({100*len(amb)/max(1,len(sub)):.1f}%)")
    sub = [r for r in rows if r["k"] >= 3]
    # true support strictly inside the spectrum or at an endpoint
    amb = [r for r in sub if r["nsizes"] > 1]
    under = sum(1 for r in amb if r["essential"] < r["kmax"])
    print("among ambiguous nodes with k>=3: true support below k_max:", under, "of", len(amb))
    print("max spectrum width among real nodes:", max((r["kmax"] - r["kmin"]) for r in rows))
    print("models with at least one ambiguous node (k>=3):", len({r['model'] for r in amb}))
