import itertools, math
for n in (5,6,7,8):
 layers={k:[x for x in range(1<<n) if x.bit_count()==k] for k in (2,3,4)}
 squares=[]
 for a in layers[2]:
  missing=[i for i in range(n) if not (a>>i&1)]
  for i,j in itertools.combinations(missing,2):
   squares.append(frozenset([a,a|(1<<i),a|(1<<j),a|(1<<i)|(1<<j)]))
 square_set=set(squares)
 failures=[];pairs=0
 for k,L in layers.items():
  for a,b in itertools.combinations(L,2):
   pairs+=1
   if not any(a in s and b not in s and frozenset((s-{a})|{b}) not in square_set for s in squares):
    failures.append((k,a,b))
 print('n',n,'N',sum(map(len,layers.values())),'squares',len(squares),'pairs',pairs,'failures',len(failures),'example',failures[:2])
