# Point C — Full-profile infinite family: analytic theorem and audit

## Model
For every n>=5 consider the complete set F_n of Boolean functions f:{0,1}^n->{0,1} with one positive address in layer 2, two in layer 3, one in layer 4, and zero positives otherwise. Thus the **entire Hamming-layer profile** is

P_n(t)=t^2+2t^3+t^4.

The learner knows P_n and may ask membership queries f(x); the target is the **essential-variable support**, not the full truth table. Cost is worst-case number of additional queries; cost of obtaining P_n is excluded. No block structure or other side promise is imposed.

## Theorem (proved)
Let M_k=binom(n,k). For all n>=5,

 Q_NA(F_n) = M_2+M_3+M_4-3.

There is a deterministic adaptive strategy satisfying

 Q_A(F_n) <= M_2+M_4-2 + 2 min(4,n-2).

Consequently,

 Q_NA(F_n)-Q_A(F_n) >= M_3 - 1 - 2 min(4,n-2),

which is strictly positive for n>=5 and diverges as Theta(n^3). In particular n=5 yields 22 vs an analytical adaptive upper bound of 19 (the previously computed 14 remains a sharper case-specific upper bound).

### Nonadaptive upper bound
Ask all but one address of each of layers 2,3,4. The final value on each layer follows from its known count (1,2,1), so reconstruct all positive addresses, hence support, in M_2+M_3+M_4-3 queries.

### Nonadaptive lower bound
For any two distinct addresses a,b of the same layer k in {2,3,4}, construct a pair of functions f,g in F_n whose positive sets differ only by replacing a with b and which have different essential supports.

Choose a two-dimensional axis-aligned Boolean subcube S={u,u+e_i,u+e_j,u+e_i+e_j}, with |u|=2 and i,j not in supp(u), containing a but not b. This is always possible for n>=5: if |a|=2 or 4, any subcube having a as its unique address at that layer excludes b; if |a|=3, choose the other middle-layer address different from b (there are 3(n-3)>=6 subcubes through a but at most one through both a,b). Let f=1_S and g=1_{(S\{a})∪{b}}. Both have profile (1,2,1). For f, the support misses exactly the two free coordinates i,j, hence has size n-2. For g, the four positive points no longer form any two-dimensional subcube: an axis-aligned two-cube with the same remaining three points as S is unique, so replacing one point cannot preserve that property. Any Boolean function with four 1's missing at least two essential coordinates must be the indicator of an axis-aligned two-cube (four ones necessarily form full orbits of a free 2-bit action). Therefore g has support size at least n-1, distinct from f.

If a fixed nonadaptive query set omitted two distinct addresses a,b in a given layer, it would return identical answers on f and g, despite their different supports. So at most one query may be omitted from each layer: at least M_2+M_3+M_4-3 queries.

### Adaptive upper bound
Query all but one weight-2 address and all but one weight-4 address. By the profile, infer their unique positive addresses a (weight 2) and b (weight 4). Set I={i: a_i=0 and b_i=1}; |I|<=min(4,n-2). For every i in I, query the two weight-3 addresses a+e_i and b-e_i (discard duplicates).

A coordinate i is inessential for f precisely when all four positive points are invariant under flipping i. Because there is only one positive point in layer 2 and one in layer 4, this can happen only if i∈I and the two weight-3 positives are exactly {a+e_i,b-e_i}. Thus the queries determine all missing essential coordinates; the essential support is recovered. The query count is at most M_2-1+M_4-1+2|I|.

### Scope/novelty caveat
This is an exact theorem about the complete profile class F_n. It proves an unbounded additive adaptive advantage but NOT the exact adaptive minimax value. Novelty relative to prior mathematical literature must still be checked independently. It is not a statement about experimental sample complexity or profile-acquisition cost.

## Numerical audit
A separate exhaustive combinatorial verifier checks every same-layer pair for the constructed conflict witness for n=5,6,7,8. It prints zero failures. This is a regression test of the theorem; the proof above is analytical.
