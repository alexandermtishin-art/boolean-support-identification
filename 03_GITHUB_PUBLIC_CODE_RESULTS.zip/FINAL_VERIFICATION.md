# Pre-submission verification report — 22 October 2026

## Independent tests completed in a clean extraction

| Check | Outcome | Scope |
|---|---|---|
| Depth-14 adaptive n=5 tree | PASS | 2250 of 2250 truth tables; 16 distinct supports |
| Nonadaptive same-layer witnesses | PASS | n=5,6,7,8; 100+400+1400+4333 conflict pairs, zero failures |
| Boolean profile baseline | PASS | m=1..4, including all 65,536 Boolean functions on four variables |
| k6 capped certificates | PASS | 147/147 tasks recomputed using archived `(k, truth_table, cap_q)` task inputs; 0 differences against archived answers |
| Theorem 2 numerical B3 inequality | PASS | 224 valid `(m,j)` integer instances |

## Limits, not covered by this claim

- The 147-task computation uses inputs from a baseline CSV, because the published-network upstream raw corpus was not included in the ZIP. It independently recomputes the answers, but does not independently reconstruct source-network functions from upstream files. The program now explicitly prints that it is running in task-fixture mode.
- The original exhaustive Colab solver **completed** depth 11 with `NO`, and depth 12 with `YES_VERIFIED`. Its positive depth-12 tree was independently checked against all 2,250 functions. This package provides source code and completed statuses; the `NO` status is a solver result, not a separate independently reproducible negative proof certificate.
- The general proofs of Theorems 2–3 were previously inspected manually; finite checks do not replace a formal theorem proof. This pass does not establish full minimax values for other `(m,j)` settings by an independent exact tree search.
- Prior work citation metadata audit was reported in `TECHNICAL_AUDIT.md` of the previous manuscript package. Fresh verification of all original papers' theorem statements and all manuscript-to-citation interpretations remains a scholarly—not programmatically certified—task.
- The research ZIP is a staging release. Confirm licenses before publishing third-party datasets; assign source-code license separately.

## Reproduction

From this archive root, with Python 3.10+:

```bash
python adaptive_n5/verify_saved_tree.py
python proofs/verify_nonadaptive_witnesses.py
python src/baseline/tests_bruteforce.py
PASSES=8 python k6/verify_k6_independent.py
```

The last test should print `INPUT MODE: archived 147-row task fixture`, `JOBS 147` and `ARCHIVE_DIFFERENCES 0`.
