# Boolean support identification — reproducibility package

Public research code and calculations accompanying *Exact Support Identification of Boolean Guards from Sector Counts and Weight-Limited Queries*. The MAIN manuscript and SUPPLEMENT are distributed **separately**, not in this package.

## Directory guide

- `src/`: baseline algorithms and original model/code
- `proofs/`: mathematical derivations and finite witness checks
- `adaptive_n5/`: saved depth-12 and depth-14 trees, depth-12 verification log, and solver depth statuses
- `search/`: resumable C++ solver and Colab notebooks, including compact V2 and overnight V3
- `verification/depth11/`: independent Python/C++ attempts at a depth-11 lower bound, clearly distinguished from completed original search
- `verification/depth12/`: read-only depth-12 tree verification
- `verification/stress/`, `verification/spectra/`, `verification/null_model/`: additional checks and matched-corpus tests
- `k6/`: 147 capped-certificate verification tasks and data
- `experimental/`, `research/`: derivative research data and analysis

## Immediate verification

```bash
python adaptive_n5/verify_saved_tree.py
python proofs/verify_nonadaptive_witnesses.py
python verification/depth12/verify_colab_result.py adaptive_n5
```

The depth-12 tree is included and independently verified on all 2,250 functions; consult `EXACT_DEPTH12_CERTIFICATES.md` for provenance and the status of negative-search results.

Read `EXACT_DEPTH12_CERTIFICATES.md`, `REPRODUCIBILITY_LIMITATIONS.md`, and `DATA_PROVENANCE.md` before citing computation or laboratory data. No third-party dataset redistribution rights are implied.
