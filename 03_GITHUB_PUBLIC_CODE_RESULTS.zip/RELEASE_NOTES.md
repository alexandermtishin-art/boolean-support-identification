# Release candidate notes — 2026-10-22

- Source and certificate paths are directly browsable; no nested ZIP required.
- 14-query tree for n=5 and 147 archived tasks included.
- Added corpus-matched null-model outputs and separate support-spectrum audit tables.
- Included the completed depth-12 Colab run artifacts: independently validated depth-12 decision tree and the original exhaustive-search statuses (depth 10 NO, depth 11 NO, depth 12 YES_VERIFIED). V3 is the computation notebook, not a second independent exhaustive run.
- MAIN and SUPPLEMENT DOCX are distributed separately; none are included in this GitHub ZIP.
- Before publishing, review author licensing choices and third-party material provenance.

MAIN and SUPPLEMENT are distributed as separate submission artifacts, not in this GitHub archive.

Depth-12 witness and author-supplied completed depth statuses are now included under `adaptive_n5/`; see `EXACT_DEPTH12_CERTIFICATES.md`.
