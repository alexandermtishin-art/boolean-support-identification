# Depth-12 certificate and depth-11 solver results

The two original files supplied by the author are included in `adaptive_n5/`:

- `tree_depth12.json` — positive decision-tree certificate (SHA-256 `07f97bcde9bc5e1b4a63187d3fec366ceb29188feb5be9beac7ba7b153063a9f`).
- `certified_results.json` — original solver depth statuses: depth 10 NO, depth 11 NO, depth 12 YES_VERIFIED.

The tree was **independently rechecked in this package** for all 2,250 candidate functions. Its maximum depth is 12. The recorded output is `adaptive_n5/depth12_independent_verification.log`.

Run in Python:

```bash
python verification/depth12/verify_colab_result.py adaptive_n5
```

The NO statuses are the output of the original exhaustive solver; no independent complete negative-search certificate is included. The solver source and Colab notebooks are in `search/`. For a complete historical trace, `runs.jsonl` was not supplied and can be added if available. The multi-gigabyte binary memoization checkpoints are deliberately excluded.
